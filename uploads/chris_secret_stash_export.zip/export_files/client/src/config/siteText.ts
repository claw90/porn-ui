// Site Text Configuration
// Edit these values to customize the text displayed throughout the application

export const SITE_TEXT = {
  // Main site branding
  siteName: "Chris' Collection",
  siteTagline: "Private Archive",
  
  // Dashboard content
  dashboard: {
    welcomeTitle: "Welcome Back", 
    welcomeSubtitle: "Your personal collection with smart recommendations tailored to your taste",
    quickStatsTitle: "Collection Stats",
    recentVideosTitle: "Recently Added",
    emptyLibraryMessage: "Ready to start your collection. Add some content to get personalized recommendations.",
  },
  
  // Discovery page
  discovery: {
    pageTitle: "Discover",
    pageSubtitle: "Search the internet for new videos to add to your collection",
    generateProfileButton: "Analyze My Taste",
    discoverVideosButton: "Find New Videos", 
    generatingProfileMessage: "Learning your preferences...",
    searchingVideosMessage: "Searching for matches...",
    noVideosFoundMessage: "No matches found. Try adjusting preferences or adding more content.",
    discoveredVideosTitle: "Recommended For You",
    addToLibraryButton: "Add to Collection",
    viewVideoButton: "Watch",
    confidenceLabel: "Match:",
    sampleVideosButton: "Add Sample Videos",
    sampleVideosMessage: "Added sample videos to help test the recommendation system",
  },
  
  // Video library
  library: {
    pageTitle: "My Collection", 
    pageSubtitle: "Browse and organize your personal video library",
    searchPlaceholder: "Search videos...",
    noVideosMessage: "Your collection is empty - start adding some videos",
    addVideoButton: "Add Video",
    bulkImportTab: "Bulk Import",
    addUrlTab: "Add URL",
  },
  
  // Recommendations
  recommendations: {
    pageTitle: "Recommendations",
    pageSubtitle: "Personalized suggestions based on your viewing history and preferences",
    algorithmTabs: {
      hybrid: "For You",
      collaborative: "Similar Users", 
      contentBased: "More Like This",
      trending: "Trending"
    }
  },
  
  // Navigation
  navigation: {
    dashboard: "Home",
    videoLibrary: "Collection", 
    recommendations: "For You",
    discovery: "Discover",
    performers: "Performers",
    collections: "Playlists",
    analytics: "Stats",
    settings: "Settings"
  },
  
  // Settings
  settings: {
    pageTitle: "Settings",
    generalTab: "General",
    privacyTab: "Privacy", 
    dataTab: "Data Management",
    advancedTab: "Advanced",
    backendToolsButton: "Backend Tools",
    faceRecognitionButton: "Face Recognition"
  },
  
  // Face Recognition
  faceRecognition: {
    pageTitle: "Face Recognition Analysis",
    pageSubtitle: "Advanced face detection and matching for video content",
    uploadVideoLabel: "Upload Video File",
    uploadFaceLabel: "Upload Target Face Image", 
    analysisModesTitle: "Analysis Modes:",
    videoOnlyMode: "Video Only: Detect all faces in the video",
    faceOnlyMode: "Face Only: Analyze face characteristics", 
    bothFilesMode: "Both Files: Find specific face in video",
    analyzeButton: "Start Analysis",
    processingMessage: "Processing your analysis..."
  },
  
  // Common UI elements
  common: {
    loading: "Loading...",
    error: "An error occurred",
    success: "Success!",
    cancel: "Cancel",
    save: "Save",
    delete: "Delete", 
    edit: "Edit",
    close: "Close",
    back: "Back",
    next: "Next",
    previous: "Previous",
    search: "Search",
    filter: "Filter",
    sort: "Sort",
    refresh: "Refresh"
  }
};

// Helper function to get nested text values
export function getText(path: string): string {
  const keys = path.split('.');
  let value: any = SITE_TEXT;
  
  for (const key of keys) {
    value = value?.[key];
  }
  
  return value || path; // Return the path if text not found
}