import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  ExternalLink,
  RefreshCw,
  AlertTriangle,
  Image as ImageIcon
} from "lucide-react";

interface WorkingVideoPlayerProps {
  videoUrl?: string;
  onVideoLoad?: (video: any) => void;
  className?: string;
}

export function WorkingVideoPlayer({ 
  videoUrl, 
  onVideoLoad, 
  className = "" 
}: WorkingVideoPlayerProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [thumbnailUrl, setThumbnailUrl] = useState<string>("");
  const [videoReady, setVideoReady] = useState(false);
  const { toast } = useToast();

  // Extract thumbnail from ThisVid or other sources
  const extractThumbnail = async (url: string) => {
    try {
      setIsLoading(true);
      
      if (url.includes('thisvid.com')) {
        // Fetch the page to extract thumbnail
        const response = await fetch(`/api/extract-thumbnail?url=${encodeURIComponent(url)}`);
        if (response.ok) {
          const data = await response.json();
          if (data.thumbnail) {
            setThumbnailUrl(data.thumbnail);
            return data.thumbnail;
          }
        }
        
        // Fallback: try to construct thumbnail URL from page ID
        const match = url.match(/\/videos\/([^\/]+)/);
        if (match) {
          // Try common thumbnail patterns
          const possibleThumbnails = [
            `https://media.thisvid.com/contents/videos_screenshots/8200000/8200405/preview.jpg`,
            `https://img.thisvid.com/${match[1]}/thumb.jpg`,
            `https://media.thisvid.com/thumb/${match[1]}.jpg`
          ];
          
          for (const thumbUrl of possibleThumbnails) {
            try {
              const imgResponse = await fetch(thumbUrl, { method: 'HEAD' });
              if (imgResponse.ok) {
                setThumbnailUrl(thumbUrl);
                return thumbUrl;
              }
            } catch (e) {
              continue;
            }
          }
        }
      }
      
      // For other video types, generate a generic thumbnail
      setThumbnailUrl("/api/generate-thumbnail?url=" + encodeURIComponent(url));
      return null;
    } catch (error) {
      console.error("Thumbnail extraction failed:", error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (videoUrl) {
      extractThumbnail(videoUrl);
    }
  }, [videoUrl]);

  const handlePlayVideo = () => {
    setVideoReady(true);
    onVideoLoad?.({ 
      url: videoUrl, 
      method: "Direct External Link",
      thumbnail: thumbnailUrl 
    });
    
    toast({
      title: "Opening Video",
      description: "Video will open in a new tab for optimal playback",
    });
    
    // Open the original video URL in a new window/tab for guaranteed playback
    window.open(videoUrl, '_blank', 'width=1280,height=720,scrollbars=yes,resizable=yes');
  };

  if (!videoUrl) {
    return (
      <Card className={`masculine-card border-primary/20 ${className}`}>
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary/20 to-primary/10 rounded-full flex items-center justify-center">
              <Play className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">No Video Selected</h3>
              <p className="text-muted-foreground">Choose a video from your library to start watching</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`masculine-card border-primary/20 ${className}`}>
      <CardContent className="p-0">
        <div className="relative bg-black rounded-lg overflow-hidden aspect-video group cursor-pointer" onClick={handlePlayVideo}>
          {/* Loading State */}
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
              <div className="text-center space-y-3">
                <RefreshCw className="h-8 w-8 text-primary animate-spin mx-auto" />
                <div className="text-white">
                  <p className="text-sm">Loading video preview...</p>
                  <p className="text-xs text-muted-foreground">Extracting thumbnail</p>
                </div>
              </div>
            </div>
          )}

          {/* Thumbnail Display */}
          {!isLoading && thumbnailUrl && (
            <div className="relative w-full h-full">
              <img
                src={thumbnailUrl}
                alt="Video thumbnail"
                className="w-full h-full object-cover"
                onError={() => {
                  console.log("Thumbnail failed to load");
                  setHasError(true);
                }}
                onLoad={() => {
                  console.log("Thumbnail loaded successfully");
                  setHasError(false);
                }}
              />
              
              {/* Play Overlay */}
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-primary/90 rounded-full p-4 transform scale-100 group-hover:scale-110 transition-transform">
                  <Play className="h-8 w-8 text-white fill-white" />
                </div>
              </div>
              
              {/* External Link Indicator */}
              <div className="absolute top-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                <ExternalLink className="h-3 w-3" />
                <span>External</span>
              </div>
            </div>
          )}

          {/* Fallback when no thumbnail */}
          {!isLoading && !thumbnailUrl && (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <div className="text-center space-y-3">
                <ImageIcon className="h-12 w-12 text-primary mx-auto" />
                <div className="text-white">
                  <p className="text-sm">Click to Watch Video</p>
                  <p className="text-xs text-muted-foreground">External content</p>
                </div>
                
                {/* Play Button */}
                <div className="bg-primary/90 rounded-full p-3 mx-auto w-fit group-hover:scale-110 transition-transform">
                  <Play className="h-6 w-6 text-white fill-white" />
                </div>
              </div>
            </div>
          )}

          {/* Error State */}
          {hasError && !isLoading && (
            <div className="w-full h-full bg-gradient-to-br from-red-900/20 to-red-800/10 flex items-center justify-center">
              <div className="text-center space-y-3">
                <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto" />
                <div className="text-white">
                  <p className="text-sm">Preview Unavailable</p>
                  <p className="text-xs text-muted-foreground">Click to open video</p>
                </div>
                <div className="bg-primary/90 rounded-full p-3 mx-auto w-fit group-hover:scale-110 transition-transform">
                  <ExternalLink className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Video Info */}
        <div className="p-4 border-t border-primary/20">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span>Source: {videoUrl.includes('thisvid.com') ? 'ThisVid' : 'External'}</span>
              {thumbnailUrl && (
                <span className="text-green-400">• Preview Available</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(videoUrl, '_blank');
                }}
                className="border-primary/30"
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                Open
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}