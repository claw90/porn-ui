import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Settings,
  ExternalLink,
  RefreshCw,
  AlertTriangle
} from "lucide-react";

interface UniversalVideoPlayerProps {
  videoUrl?: string;
  onVideoLoad?: (video: any) => void;
  className?: string;
}

export function UniversalVideoPlayer({ 
  videoUrl, 
  onVideoLoad, 
  className = "" 
}: UniversalVideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [loadingMethod, setLoadingMethod] = useState(0);
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const videoRef = useRef<HTMLVideoElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { toast } = useToast();

  // Different loading methods for various video platforms
  const loadingMethods = [
    {
      name: "ThisVid Embed",
      canHandle: (url: string) => url.includes('thisvid.com'),
      getEmbedUrl: (url: string) => {
        const match = url.match(/\/videos\/([^\/]+)/);
        return match ? `https://thisvid.com/embed/${match[1]}/?autoplay=1` : url;
      },
      useVideo: false
    },
    {
      name: "Direct Iframe",
      canHandle: (url: string) => true,
      getEmbedUrl: (url: string) => url,
      useVideo: false
    },
    {
      name: "Direct Video",
      canHandle: (url: string) => url.match(/\.(mp4|webm|ogg|avi|mov)$/i),
      getEmbedUrl: (url: string) => url,
      useVideo: true
    },
    {
      name: "Proxy Embed",
      canHandle: (url: string) => true,
      getEmbedUrl: (url: string) => `https://iframe.ly/api/iframe?url=${encodeURIComponent(url)}&api_key=demo`,
      useVideo: false
    }
  ];

  const currentMethod = loadingMethods[loadingMethod];
  const embedUrl = currentMethod ? currentMethod.getEmbedUrl(videoUrl || '') : videoUrl;

  useEffect(() => {
    setHasError(false);
    setIsLoading(true);
    
    // Auto-select best method based on URL
    if (videoUrl?.includes('thisvid.com')) {
      setLoadingMethod(0); // ThisVid Embed
    } else if (videoUrl?.match(/\.(mp4|webm|ogg|avi|mov)$/i)) {
      setLoadingMethod(2); // Direct Video
    } else {
      setLoadingMethod(1); // Direct Iframe
    }
  }, [videoUrl]);

  const handleVideoLoad = () => {
    setIsLoading(false);
    setHasError(false);
    onVideoLoad?.({ url: videoUrl, method: currentMethod.name });
    toast({
      title: "Video Loaded Successfully",
      description: `Using method: ${currentMethod.name}`,
    });
  };

  const handleVideoError = () => {
    setHasError(true);
    setIsLoading(false);
    console.error(`Video loading failed with method: ${currentMethod.name}`);
  };

  const tryNextMethod = () => {
    if (loadingMethod < loadingMethods.length - 1) {
      setLoadingMethod(loadingMethod + 1);
      setHasError(false);
      setIsLoading(true);
      toast({
        title: "Trying Alternative Method",
        description: `Now testing: ${loadingMethods[loadingMethod + 1].name}`,
      });
    } else {
      toast({
        title: "All Methods Failed",
        description: "Unable to load video with any available method",
        variant: "destructive"
      });
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTime = (parseFloat(e.target.value) / 100) * duration;
    if (videoRef.current) {
      videoRef.current.currentTime = seekTime;
      setCurrentTime(seekTime);
    }
  };

  if (!videoUrl) {
    return (
      <Card className={`masculine-card border-primary/20 ${className}`}>
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary/20 to-primary/10 rounded-full flex items-center justify-center">
              <Play className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">No Video Selected</h3>
              <p className="text-muted-foreground">Choose a video from your library to start watching</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`masculine-card border-primary/20 ${className}`}>
      <CardContent className="p-0">
        <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
          {/* Loading State */}
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
              <div className="text-center space-y-3">
                <RefreshCw className="h-8 w-8 text-primary animate-spin mx-auto" />
                <div className="text-white">
                  <p className="text-sm">Loading video...</p>
                  <p className="text-xs text-muted-foreground">Method: {currentMethod.name}</p>
                </div>
              </div>
            </div>
          )}

          {/* Error State */}
          {hasError && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
              <div className="text-center space-y-3">
                <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto" />
                <div className="text-white space-y-2">
                  <p className="text-sm">Failed to load with {currentMethod.name}</p>
                  <div className="flex gap-2 justify-center">
                    <Button size="sm" onClick={tryNextMethod} className="masculine-gradient">
                      Try Next Method
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => window.open(videoUrl, '_blank')}>
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Open Original
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Video Element */}
          {currentMethod.useVideo ? (
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              onLoadStart={() => setIsLoading(true)}
              onCanPlay={handleVideoLoad}
              onError={handleVideoError}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              controls={false}
              autoPlay
              muted={isMuted}
            >
              <source src={embedUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <iframe
              ref={iframeRef}
              src={embedUrl}
              className="w-full h-full"
              allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
              allowFullScreen
              frameBorder="0"
              sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-presentation"
              onLoad={handleVideoLoad}
              onError={handleVideoError}
            />
          )}

          {/* Custom Controls for video element */}
          {currentMethod.useVideo && !isLoading && !hasError && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="space-y-2">
                {/* Progress Bar */}
                <div className="flex items-center gap-2 text-white text-xs">
                  <span>{formatTime(currentTime)}</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={duration ? (currentTime / duration) * 100 : 0}
                    onChange={handleSeek}
                    className="flex-1 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <span>{formatTime(duration)}</span>
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="ghost" onClick={togglePlay} className="text-white hover:text-primary">
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={toggleMute} className="text-white hover:text-primary">
                      {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="ghost" className="text-white hover:text-primary">
                      <Settings className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-white hover:text-primary">
                      <Maximize className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Method Indicator */}
          <div className="absolute top-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
            {currentMethod.name}
          </div>
        </div>

        {/* Debug Info */}
        <div className="p-4 border-t border-primary/20">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div>
              <span>URL: {videoUrl.substring(0, 50)}...</span>
            </div>
            <div className="flex items-center gap-2">
              <span>Method {loadingMethod + 1}/{loadingMethods.length}: {currentMethod.name}</span>
              <Button size="sm" variant="outline" onClick={() => window.open(videoUrl, '_blank')}>
                <ExternalLink className="h-3 w-3 mr-1" />
                Source
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}