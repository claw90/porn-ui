import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { RealTimeFaceRecognition } from "./RealTimeFaceRecognition";
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Upload,
  Camera,
  ExternalLink
} from "lucide-react";

interface VideoPlayerProps {
  videoUrl?: string;
  onVideoLoad?: (video: HTMLVideoElement) => void;
}

export function VideoPlayer({ videoUrl, onVideoLoad }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [targetFaceImage, setTargetFaceImage] = useState<string>("");
  const [showFaceRecognition, setShowFaceRecognition] = useState(false);
  const [videoError, setVideoError] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const faceInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();

  // Extract embed URL for external platforms
  const getEmbedUrl = (url: string) => {
    if (!url) return null;
    
    try {
      if (url.includes('thisvid.com')) {
        // Extract video ID from thisvid URL
        const match = url.match(/\/videos\/([^\/]+)/);
        if (match) {
          const videoId = match[1];
          return `https://thisvid.com/embed/${videoId}`;
        }
        return url; // Fallback to original URL
      }
      
      if (url.includes('youtube.com/watch')) {
        const videoId = new URL(url).searchParams.get('v');
        return `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1`;
      }
      
      if (url.includes('pornhub.com')) {
        const viewkey = new URL(url).searchParams.get('viewkey');
        return `https://www.pornhub.com/embed/${viewkey}`;
      }
      
      if (url.includes('xvideos.com')) {
        const videoId = url.split('/videos/')[1]?.split('/')[0];
        return `https://www.xvideos.com/embedframe/${videoId}`;
      }
      
      if (url.includes('redtube.com')) {
        const videoId = url.split('/')[url.split('/').length - 1];
        return `https://embed.redtube.com/?id=${videoId}`;
      }
      
      if (url.includes('xhamster.com')) {
        const videoId = url.split('/videos/')[1]?.split('-')[0];
        return `https://xhamster.com/embed/${videoId}`;
      }
      
      // For direct video files or other platforms, try using the URL directly
      return url;
    } catch (error) {
      return url;
    }
  };

  // Check if URL needs iframe embedding
  const needsIframe = (url: string) => {
    if (!url) return false;
    return url.includes('thisvid.com') || 
           url.includes('youtube.com') || 
           url.includes('pornhub.com') || 
           url.includes('xvideos.com') ||
           url.includes('redtube.com') ||
           url.includes('xhamster.com') ||
           url.includes('youporn.com') ||
           url.includes('xnxx.com');
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!videoRef.current) return;
    
    const newVolume = parseFloat(e.target.value);
    videoRef.current.volume = newVolume;
    setVolume(newVolume);
    setIsMuted(newVolume === 0);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    setCurrentTime(videoRef.current.currentTime);
  };

  const handleVideoLoad = () => {
    if (!videoRef.current) return;
    setDuration(videoRef.current.duration);
    setVideoError(false);
    onVideoLoad?.(videoRef.current);
  };

  const handleVideoError = () => {
    setVideoError(true);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!videoRef.current) return;
    
    const newTime = parseFloat(e.target.value);
    videoRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    if (videoRef.current) {
      videoRef.current.src = url;
    }

    toast({
      title: "Video Loaded",
      description: `${file.name} loaded successfully`,
    });
  };

  const handleFaceImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setTargetFaceImage(result);
      toast({
        title: "Target Face Loaded",
        description: "Face image ready for real-time recognition",
      });
    };
    reader.readAsDataURL(file);
  };

  const toggleFullscreen = () => {
    const element = iframeRef.current || videoRef.current;
    if (!element) return;
    
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      element.requestFullscreen();
    }
  };

  const extractVideoTitle = (url: string) => {
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.replace('www.', '');
      const pathSegments = urlObj.pathname.split('/').filter(Boolean);
      
      if (pathSegments.length > 0) {
        const lastSegment = pathSegments[pathSegments.length - 1];
        return lastSegment.replace(/[-_]/g, ' ').replace(/\.[^/.]+$/, '').substring(0, 50);
      }
      
      return hostname.charAt(0).toUpperCase() + hostname.slice(1) + ' Video';
    } catch {
      return 'External Video';
    }
  };

  const embedUrl = videoUrl ? getEmbedUrl(videoUrl) : null;
  const useIframe = videoUrl ? needsIframe(videoUrl) : false;

  return (
    <div className="space-y-4">
      <Card className="masculine-card border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <span>Video Player</span>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="border-primary/30"
              >
                <Upload className="h-4 w-4 mr-2" />
                Load Video
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => faceInputRef.current?.click()}
                className="border-primary/30"
              >
                <Camera className="h-4 w-4 mr-2" />
                Target Face
              </Button>
              {!useIframe && (
                <Button
                  size="sm"
                  variant={showFaceRecognition ? "default" : "outline"}
                  onClick={() => setShowFaceRecognition(!showFaceRecognition)}
                  className={showFaceRecognition ? "masculine-gradient" : "border-primary/30"}
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Real-time AI
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Hidden file inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleVideoUpload}
            className="hidden"
          />
          <input
            ref={faceInputRef}
            type="file"
            accept="image/*"
            onChange={handleFaceImageUpload}
            className="hidden"
          />

          {/* Video Element */}
          <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
            {videoUrl ? (
              useIframe ? (
                // Embedded external videos
                <iframe
                  ref={iframeRef}
                  src={embedUrl || videoUrl}
                  className="w-full h-full"
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                  frameBorder="0"
                  sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
                  onLoad={() => {
                    toast({
                      title: "Video Loaded",
                      description: "External video embedded successfully",
                    });
                  }}
                  onError={() => {
                    toast({
                      title: "Embed Failed",
                      description: "Trying alternative loading method",
                      variant: "destructive"
                    });
                  }}
                />
              ) : (
                // Direct video files
                <>
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    autoPlay
                    muted
                    playsInline
                    onTimeUpdate={handleTimeUpdate}
                    onLoadedMetadata={handleVideoLoad}
                    onError={handleVideoError}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    className="w-full h-full object-contain"
                    controls={false}
                  />
                  
                  {videoError && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/80 text-white">
                      <div className="text-center space-y-2">
                        <p>Video cannot be played directly</p>
                        <Button 
                          size="sm"
                          onClick={() => window.open(videoUrl, '_blank')}
                          className="masculine-gradient"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Open in New Tab
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {/* Video Controls Overlay */}
                  {!videoError && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                      {/* Progress Bar */}
                      <input
                        type="range"
                        min={0}
                        max={duration}
                        value={currentTime}
                        onChange={handleSeek}
                        className="w-full h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer mb-2"
                      />
                      
                      {/* Control Buttons */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={togglePlay}
                            className="text-white hover:bg-white/20"
                          >
                            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={toggleMute}
                            className="text-white hover:bg-white/20"
                          >
                            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                          </Button>
                          
                          <input
                            type="range"
                            min={0}
                            max={1}
                            step={0.1}
                            value={volume}
                            onChange={handleVolumeChange}
                            className="w-20 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                          />
                          
                          <span className="text-white text-sm">
                            {formatTime(currentTime)} / {formatTime(duration)}
                          </span>
                        </div>
                        
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={toggleFullscreen}
                          className="text-white hover:bg-white/20"
                        >
                          <Maximize className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )
            ) : (
              // No video selected
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-black text-white">
                <div className="text-center space-y-4">
                  <Upload className="w-16 h-16 text-gray-500 mx-auto" />
                  <p className="text-gray-400">Select a video from the library</p>
                </div>
              </div>
            )}
          </div>

          {/* Real-time Face Recognition */}
          {showFaceRecognition && targetFaceImage && videoRef.current && !useIframe && (
            <RealTimeFaceRecognition
              videoElement={videoRef.current}
              targetFaceImage={targetFaceImage}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}