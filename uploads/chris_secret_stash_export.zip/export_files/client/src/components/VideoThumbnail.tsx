import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  Star, 
  ExternalLink, 
  Clock,
  Eye,
  Link as LinkIcon
} from "lucide-react";

interface VideoThumbnailProps {
  video?: {
    id: string;
    title: string;
    videoUrl?: string;
    duration?: number;
    viewCount?: number;
    rating?: number;
    isExternal?: boolean;
    thumbnailPath?: string;
  };
  onClick?: () => void;
  className?: string;
}

export function VideoThumbnail({ video, onClick, className = "" }: VideoThumbnailProps) {
  const [thumbnailUrl, setThumbnailUrl] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Early return if no video data
  if (!video) {
    return (
      <Card className={`bg-gray-800 border-gray-700 ${className}`}>
        <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
          <Play className="w-8 h-8 text-gray-500" />
        </div>
        <div className="p-3">
          <h3 className="text-white text-sm">No video data</h3>
        </div>
      </Card>
    );
  }

  // Extract video title from URL
  const extractVideoTitle = (url: string) => {
    try {
      const urlObj = new URL(url);
      const pathSegments = urlObj.pathname.split('/').filter(Boolean);
      
      if (pathSegments.length > 0) {
        const lastSegment = pathSegments[pathSegments.length - 1];
        const title = lastSegment
          .replace(/[-_]/g, ' ')
          .replace(/\.[^/.]+$/, '')
          .split(' ')
          .map(word => word.charAt(0).toUpperCase() + word.slice(1))
          .join(' ');
        return title.substring(0, 40) + (title.length > 40 ? '...' : '');
      }
      
      return urlObj.hostname.replace('www.', '').charAt(0).toUpperCase() + 
             urlObj.hostname.replace('www.', '').slice(1) + ' Video';
    } catch {
      return 'Video Content';
    }
  };

  // Generate thumbnail from video
  const generateThumbnail = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setIsGenerating(true);
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = 160;
    canvas.height = 90;

    const captureFrame = () => {
      if (video.readyState >= 2) {
        // Draw video frame to canvas
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert to data URL
        const dataURL = canvas.toDataURL('image/jpeg', 0.8);
        setThumbnailUrl(dataURL);
        setIsGenerating(false);
      } else {
        // Wait for video to load
        setTimeout(captureFrame, 100);
      }
    };

    // Set video to middle timestamp for better thumbnail
    video.currentTime = video.duration ? video.duration * 0.3 : 5;
    video.addEventListener('seeked', captureFrame, { once: true });
  };

  // Create platform-specific thumbnail
  const getPlatformThumbnail = (url: string) => {
    try {
      if (url.includes('youtube.com')) {
        const videoId = new URL(url).searchParams.get('v');
        return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
      }
      
      if (url.includes('thisvid.com')) {
        // Generate a generic placeholder for thisvid
        return generatePlaceholderThumbnail(url);
      }
      
      // For other platforms, generate placeholder
      return generatePlaceholderThumbnail(url);
    } catch {
      return generatePlaceholderThumbnail(url);
    }
  };

  // Generate placeholder thumbnail
  const generatePlaceholderThumbnail = (url: string) => {
    if (!canvasRef.current) return "";
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return "";

    canvas.width = 160;
    canvas.height = 90;

    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, 320, 180);
    gradient.addColorStop(0, '#1a1a1a');
    gradient.addColorStop(1, '#333333');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 320, 180);

    // Add play icon
    ctx.fillStyle = '#ff6b35';
    ctx.beginPath();
    ctx.arc(160, 90, 30, 0, 2 * Math.PI);
    ctx.fill();

    // Add triangle (play symbol)
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(150, 75);
    ctx.lineTo(150, 105);
    ctx.lineTo(175, 90);
    ctx.closePath();
    ctx.fill();

    // Add platform name
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px sans-serif';
    ctx.textAlign = 'center';
    const hostname = new URL(url).hostname.replace('www.', '');
    ctx.fillText(hostname.toUpperCase(), 160, 140);

    return canvas.toDataURL('image/jpeg', 0.8);
  };

  useEffect(() => {
    if (video?.videoUrl) {
      if (video.isExternal) {
        // For external videos, try platform-specific thumbnail
        const platformThumb = getPlatformThumbnail(video.videoUrl);
        if (platformThumb) {
          setThumbnailUrl(platformThumb);
        }
      } else {
        // For direct video files, generate thumbnail
        generateThumbnail();
      }
    }
  }, [video?.videoUrl, video?.isExternal]);

  const displayTitle = video.title === 'External Video' && video.videoUrl ? 
    extractVideoTitle(video.videoUrl) : 
    video.title;

  const formatDuration = (seconds?: number) => {
    if (!seconds) return "Unknown";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const formatViewCount = (count?: number) => {
    if (!count) return "0";
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  return (
    <>
      {/* Hidden video element for thumbnail generation */}
      {!video.isExternal && video.videoUrl && (
        <video
          ref={videoRef}
          src={video.videoUrl}
          muted
          preload="metadata"
          className="hidden"
          onLoadedMetadata={generateThumbnail}
        />
      )}
      
      {/* Hidden canvas for thumbnail generation */}
      <canvas ref={canvasRef} className="hidden" />
      
      <Card 
        className={`masculine-card hover-glow border-primary/20 cursor-pointer transition-all duration-200 hover:border-primary/40 ${className}`}
        onClick={onClick}
      >
        <div className="relative">
          {/* Thumbnail */}
          <div className="relative aspect-video bg-gradient-to-br from-gray-900 to-black rounded-t-lg overflow-hidden">
            {thumbnailUrl ? (
              <img 
                src={thumbnailUrl}
                alt={displayTitle}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                {isGenerating ? (
                  <div className="text-center space-y-2">
                    <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    <p className="text-xs text-gray-400">Generating...</p>
                  </div>
                ) : (
                  <div className="text-center space-y-2">
                    <Play className="w-12 h-12 text-primary/60 mx-auto" />
                    <p className="text-xs text-gray-400">Video Thumbnail</p>
                  </div>
                )}
              </div>
            )}
            
            {/* Play overlay */}
            <div className="absolute inset-0 bg-black/0 hover:bg-black/30 transition-all duration-200 flex items-center justify-center">
              <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-200">
                <Play className="w-8 h-8 text-white ml-1" />
              </div>
            </div>
            
            {/* Duration badge */}
            {video.duration && (
              <Badge 
                variant="secondary" 
                className="absolute bottom-2 right-2 bg-black/80 text-white text-xs"
              >
                <Clock className="w-3 h-3 mr-1" />
                {formatDuration(video.duration)}
              </Badge>
            )}
            
            {/* External video indicator */}
            {video.isExternal && (
              <Badge 
                variant="secondary" 
                className="absolute top-2 right-2 bg-blue-500/80 text-white text-xs"
              >
                <LinkIcon className="w-3 h-3 mr-1" />
                External
              </Badge>
            )}
          </div>
          
          {/* Video info */}
          <div className="p-3 space-y-2">
            <h3 className="font-medium text-sm line-clamp-2 text-foreground leading-tight">
              {displayTitle}
            </h3>
            
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-3">
                {video.viewCount !== undefined && (
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    {formatViewCount(video.viewCount)}
                  </span>
                )}
                
                {video.rating && video.rating > 0 && (
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i}
                        className={`w-3 h-3 ${
                          i < (video.rating || 0) 
                            ? 'text-yellow-400 fill-current' 
                            : 'text-gray-400'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </div>
              
              {video.isExternal && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(video.videoUrl, '_blank');
                  }}
                >
                  <ExternalLink className="w-3 h-3" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>
    </>
  );
}