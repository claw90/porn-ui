import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings,
  Plus,
  X,
  Star,
  Clock,
  Tag,
  Users,
  Shield,
  Zap
} from "lucide-react";

interface UserPreferencesProps {
  userId: string;
  className?: string;
}

interface Preferences {
  preferredTags: string[];
  preferredPerformers: string[];
  preferredCategories: string[];
  blockedTags: string[];
  blockedPerformers: string[];
  minRating: number;
  maxDuration: number;
  minDuration: number;
}

export default function UserPreferences({ userId, className = "" }: UserPreferencesProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [newTag, setNewTag] = useState("");
  const [newPerformer, setNewPerformer] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [newBlockedTag, setNewBlockedTag] = useState("");
  const [newBlockedPerformer, setNewBlockedPerformer] = useState("");

  // Fetch current preferences (mock for now since we need actual user data)
  const { data: preferences, isLoading } = useQuery({
    queryKey: ['/api/users', userId, 'preferences'],
    enabled: false, // Disable until we have real user endpoints
  });

  const [localPreferences, setLocalPreferences] = useState<Preferences>({
    preferredTags: [],
    preferredPerformers: [],
    preferredCategories: [],
    blockedTags: [],
    blockedPerformers: [],
    minRating: 0,
    maxDuration: 0,
    minDuration: 0,
    ...preferences
  });

  // Update preferences mutation
  const updatePreferences = useMutation({
    mutationFn: async (prefs: Preferences) => {
      const response = await fetch(`/api/recommendations/preferences/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(prefs),
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
      toast({
        title: "Preferences Updated",
        description: "Your recommendation preferences have been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSavePreferences = () => {
    updatePreferences.mutate(localPreferences);
  };

  const addToList = (list: keyof Preferences, value: string, setter: (val: string) => void) => {
    if (!value.trim()) return;
    
    const currentList = localPreferences[list] as string[];
    if (!currentList.includes(value.trim())) {
      setLocalPreferences(prev => ({
        ...prev,
        [list]: [...currentList, value.trim()]
      }));
    }
    setter("");
  };

  const removeFromList = (list: keyof Preferences, value: string) => {
    const currentList = localPreferences[list] as string[];
    setLocalPreferences(prev => ({
      ...prev,
      [list]: currentList.filter(item => item !== value)
    }));
  };

  const formatDuration = (seconds: number) => {
    if (seconds === 0) return "No limit";
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  if (isLoading) {
    return (
      <Card className={`masculine-card border-primary/10 ${className}`}>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted/20 rounded w-1/3"></div>
            <div className="h-20 bg-muted/20 rounded"></div>
            <div className="h-4 bg-muted/20 rounded w-1/4"></div>
            <div className="h-20 bg-muted/20 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`masculine-card border-primary/10 ${className}`}>
      <CardHeader>
        <CardTitle className="text-lg masculine-text-gradient flex items-center gap-2">
          <Settings className="w-5 h-5 text-primary" />
          Recommendation Preferences
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Preferred Tags */}
        <div className="space-y-3">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Tag className="w-4 h-4 text-primary" />
            Preferred Tags
          </Label>
          <div className="flex gap-2">
            <Input
              placeholder="Add preferred tag..."
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addToList('preferredTags', newTag, setNewTag)}
              className="flex-1"
            />
            <Button
              size="sm"
              onClick={() => addToList('preferredTags', newTag, setNewTag)}
              className="masculine-gradient"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {localPreferences.preferredTags.map((tag) => (
              <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                #{tag}
                <X
                  className="w-3 h-3 cursor-pointer hover:text-destructive"
                  onClick={() => removeFromList('preferredTags', tag)}
                />
              </Badge>
            ))}
          </div>
        </div>

        <Separator />

        {/* Preferred Performers */}
        <div className="space-y-3">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            Preferred Performers
          </Label>
          <div className="flex gap-2">
            <Input
              placeholder="Add preferred performer..."
              value={newPerformer}
              onChange={(e) => setNewPerformer(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addToList('preferredPerformers', newPerformer, setNewPerformer)}
              className="flex-1"
            />
            <Button
              size="sm"
              onClick={() => addToList('preferredPerformers', newPerformer, setNewPerformer)}
              className="masculine-gradient"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {localPreferences.preferredPerformers.map((performer) => (
              <Badge key={performer} variant="secondary" className="flex items-center gap-1">
                {performer}
                <X
                  className="w-3 h-3 cursor-pointer hover:text-destructive"
                  onClick={() => removeFromList('preferredPerformers', performer)}
                />
              </Badge>
            ))}
          </div>
        </div>

        <Separator />

        {/* Rating Filter */}
        <div className="space-y-3">
          <Label className="text-sm font-medium flex items-center gap-2">
            <Star className="w-4 h-4 text-primary" />
            Minimum Rating: {localPreferences.minRating}/5
          </Label>
          <Slider
            value={[localPreferences.minRating]}
            onValueChange={(value) => setLocalPreferences(prev => ({ ...prev, minRating: value[0] }))}
            max={5}
            step={1}
            className="w-full"
          />
        </div>

        <Separator />

        {/* Duration Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Min Duration: {formatDuration(localPreferences.minDuration)}
            </Label>
            <Slider
              value={[localPreferences.minDuration]}
              onValueChange={(value) => setLocalPreferences(prev => ({ ...prev, minDuration: value[0] }))}
              max={7200} // 2 hours
              step={300} // 5 minute steps
              className="w-full"
            />
          </div>
          
          <div className="space-y-3">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Max Duration: {formatDuration(localPreferences.maxDuration)}
            </Label>
            <Slider
              value={[localPreferences.maxDuration]}
              onValueChange={(value) => setLocalPreferences(prev => ({ ...prev, maxDuration: value[0] }))}
              max={7200} // 2 hours
              step={300} // 5 minute steps
              className="w-full"
            />
          </div>
        </div>

        <Separator />

        {/* Blocked Content */}
        <div className="space-y-4">
          <Label className="text-sm font-medium flex items-center gap-2 text-destructive">
            <Shield className="w-4 h-4" />
            Blocked Content
          </Label>
          
          {/* Blocked Tags */}
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Blocked Tags</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add blocked tag..."
                value={newBlockedTag}
                onChange={(e) => setNewBlockedTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addToList('blockedTags', newBlockedTag, setNewBlockedTag)}
                className="flex-1"
              />
              <Button
                size="sm"
                variant="destructive"
                onClick={() => addToList('blockedTags', newBlockedTag, setNewBlockedTag)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {localPreferences.blockedTags.map((tag) => (
                <Badge key={tag} variant="destructive" className="flex items-center gap-1">
                  #{tag}
                  <X
                    className="w-3 h-3 cursor-pointer"
                    onClick={() => removeFromList('blockedTags', tag)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Blocked Performers */}
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Blocked Performers</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add blocked performer..."
                value={newBlockedPerformer}
                onChange={(e) => setNewBlockedPerformer(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addToList('blockedPerformers', newBlockedPerformer, setNewBlockedPerformer)}
                className="flex-1"
              />
              <Button
                size="sm"
                variant="destructive"
                onClick={() => addToList('blockedPerformers', newBlockedPerformer, setNewBlockedPerformer)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {localPreferences.blockedPerformers.map((performer) => (
                <Badge key={performer} variant="destructive" className="flex items-center gap-1">
                  {performer}
                  <X
                    className="w-3 h-3 cursor-pointer"
                    onClick={() => removeFromList('blockedPerformers', performer)}
                  />
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pt-4">
          <Button
            onClick={handleSavePreferences}
            disabled={updatePreferences.isPending}
            className="masculine-gradient hover:scale-105 transition-transform duration-300 glow-primary"
          >
            <Zap className="w-4 h-4 mr-2" />
            {updatePreferences.isPending ? 'Saving...' : 'Save Preferences'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}