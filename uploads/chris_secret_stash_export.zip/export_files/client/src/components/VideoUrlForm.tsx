import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link, Globe, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface VideoUrlFormData {
  title: string;
  videoUrl: string;
  thumbnailPath?: string;
  tags: string[];
  performers: string[];
  categories: string[];
  notes?: string;
}

interface VideoUrlFormProps {
  onSuccess?: () => void;
}

export function VideoUrlForm({ onSuccess }: VideoUrlFormProps) {
  const [formData, setFormData] = useState<VideoUrlFormData>({
    title: "",
    videoUrl: "",
    thumbnailPath: "",
    tags: [],
    performers: [],
    categories: [],
    notes: "",
  });

  const [tagInput, setTagInput] = useState("");
  const [performerInput, setPerformerInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createVideoMutation = useMutation({
    mutationFn: (data: VideoUrlFormData) => apiRequest("/api/videos/url", "POST", data),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Video URL added successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setFormData({
        title: "",
        videoUrl: "",
        thumbnailPath: "",
        tags: [],
        performers: [],
        categories: [],
        notes: "",
      });
      onSuccess?.();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add video URL",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.videoUrl.trim()) {
      toast({
        title: "Error",
        description: "Video URL is required",
        variant: "destructive",
      });
      return;
    }

    // Basic URL validation
    try {
      new URL(formData.videoUrl);
    } catch {
      toast({
        title: "Error",
        description: "Please enter a valid URL",
        variant: "destructive",
      });
      return;
    }

    createVideoMutation.mutate(formData);
  };

  const addTag = (type: 'tags' | 'performers' | 'categories', value: string, setValue: (value: string) => void) => {
    if (value.trim() && !formData[type].includes(value.trim())) {
      setFormData(prev => ({
        ...prev,
        [type]: [...prev[type], value.trim()]
      }));
      setValue("");
    }
  };

  const removeTag = (type: 'tags' | 'performers' | 'categories', index: number) => {
    setFormData(prev => ({
      ...prev,
      [type]: prev[type].filter((_, i) => i !== index)
    }));
  };

  const handleKeyPress = (e: React.KeyboardEvent, type: 'tags' | 'performers' | 'categories', value: string, setValue: (value: string) => void) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag(type, value, setValue);
    }
  };

  return (
    <Card className="masculine-card border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-primary" />
          <span className="masculine-text-gradient">Add Video URL</span>
        </CardTitle>
        <CardDescription>
          Add external video URLs to your library for easy access and organization
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="videoUrl">Video URL *</Label>
              <Input
                id="videoUrl"
                type="url"
                placeholder="https://example.com/video.mp4"
                value={formData.videoUrl}
                onChange={(e) => setFormData(prev => ({ ...prev, videoUrl: e.target.value }))}
                className="bg-muted/50 border-primary/20 focus:border-primary"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                type="text"
                placeholder="Enter video title (optional)"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="bg-muted/50 border-primary/20 focus:border-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="thumbnailPath">Thumbnail URL (optional)</Label>
            <Input
              id="thumbnailPath"
              type="url"
              placeholder="https://example.com/thumbnail.jpg"
              value={formData.thumbnailPath}
              onChange={(e) => setFormData(prev => ({ ...prev, thumbnailPath: e.target.value }))}
              className="bg-muted/50 border-primary/20 focus:border-primary"
            />
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add tags (press Enter)"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, 'tags', tagInput, setTagInput)}
                className="bg-muted/50 border-primary/20 focus:border-primary"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => addTag('tags', tagInput, setTagInput)}
                className="border-primary/30 hover:bg-primary/10"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.tags.map((tag, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-destructive/20"
                  onClick={() => removeTag('tags', index)}
                >
                  {tag} ×
                </Badge>
              ))}
            </div>
          </div>

          {/* Performers */}
          <div className="space-y-2">
            <Label>Performers</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add performers (press Enter)"
                value={performerInput}
                onChange={(e) => setPerformerInput(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, 'performers', performerInput, setPerformerInput)}
                className="bg-muted/50 border-primary/20 focus:border-primary"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => addTag('performers', performerInput, setPerformerInput)}
                className="border-primary/30 hover:bg-primary/10"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.performers.map((performer, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-destructive/20"
                  onClick={() => removeTag('performers', index)}
                >
                  {performer} ×
                </Badge>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-2">
            <Label>Categories</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add categories (press Enter)"
                value={categoryInput}
                onChange={(e) => setCategoryInput(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, 'categories', categoryInput, setCategoryInput)}
                className="bg-muted/50 border-primary/20 focus:border-primary"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => addTag('categories', categoryInput, setCategoryInput)}
                className="border-primary/30 hover:bg-primary/10"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.categories.map((category, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-destructive/20"
                  onClick={() => removeTag('categories', index)}
                >
                  {category} ×
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea
              id="notes"
              placeholder="Add any additional notes about this video..."
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="bg-muted/50 border-primary/20 focus:border-primary min-h-[80px]"
            />
          </div>

          <Button
            type="submit"
            disabled={createVideoMutation.isPending}
            className="w-full masculine-gradient hover:scale-105 transition-transform duration-300 glow-primary"
          >
            {createVideoMutation.isPending ? (
              "Adding Video..."
            ) : (
              <>
                <Link className="w-4 h-4 mr-2" />
                Add Video URL
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}