import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye, Clock, CheckCircle, X, History } from "lucide-react";
// Date formatting utility
function formatDate(dateString: string, formatStr: string): string {
  const date = new Date(dateString);
  if (formatStr === 'MMM d, yyyy') {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  }
  if (formatStr === 'MMM d, yyyy HH:mm') {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
  return date.toLocaleDateString();
}

interface WatchHistoryNotificationProps {
  videoId: string;
  onDismiss?: () => void;
}

interface WatchHistory {
  hasWatched: boolean;
  lastWatched?: string;
  viewCount: number;
  completed: boolean;
}

export function WatchHistoryNotification({ videoId, onDismiss }: WatchHistoryNotificationProps) {
  const [showDetails, setShowDetails] = useState(false);

  const { data: watchHistory } = useQuery<WatchHistory>({
    queryKey: [`/api/videos/${videoId}/watch-history`],
    enabled: !!videoId,
  });

  if (!watchHistory?.hasWatched) {
    return null;
  }

  return (
    <Alert className="border-orange-500/50 bg-orange-500/10 mb-4">
      <History className="h-4 w-4 text-orange-500" />
      <AlertDescription className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4 text-orange-400" />
            <span className="text-orange-100">
              You've watched this video before
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-orange-500/20 text-orange-300">
              {watchHistory.viewCount}x viewed
            </Badge>
            
            {watchHistory.completed && (
              <Badge variant="secondary" className="bg-green-500/20 text-green-300">
                <CheckCircle className="h-3 w-3 mr-1" />
                Completed
              </Badge>
            )}
          </div>

          {watchHistory.lastWatched && (
            <div className="flex items-center gap-1 text-xs text-orange-300">
              <Clock className="h-3 w-3" />
              Last: {formatDate(watchHistory.lastWatched, 'MMM d, yyyy')}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowDetails(!showDetails)}
            className="text-orange-300 hover:text-orange-100 hover:bg-orange-500/20"
          >
            {showDetails ? 'Hide' : 'Details'}
          </Button>
          
          {onDismiss && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onDismiss}
              className="text-orange-300 hover:text-orange-100 hover:bg-orange-500/20"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </AlertDescription>

      {showDetails && (
        <div className="mt-4 pt-4 border-t border-orange-500/30">
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-orange-300 font-medium">Total Views</div>
              <div className="text-orange-100">{watchHistory.viewCount}</div>
            </div>
            <div>
              <div className="text-orange-300 font-medium">Status</div>
              <div className="text-orange-100">
                {watchHistory.completed ? 'Completed' : 'Partially watched'}
              </div>
            </div>
            <div>
              <div className="text-orange-300 font-medium">Last Watched</div>
              <div className="text-orange-100">
                {watchHistory.lastWatched 
                  ? formatDate(watchHistory.lastWatched, 'MMM d, yyyy HH:mm')
                  : 'Unknown'
                }
              </div>
            </div>
          </div>
        </div>
      )}
    </Alert>
  );
}

interface ViewingHistoryProps {
  limit?: number;
}

export function ViewingHistory({ limit = 20 }: ViewingHistoryProps) {
  const { data: history = [], isLoading } = useQuery({
    queryKey: [`/api/viewing-history`, limit],
  });

  if (isLoading) {
    return (
      <Card className="masculine-card">
        <CardContent className="p-4">
          <div className="animate-pulse flex space-x-4">
            <div className="rounded-full bg-gray-300 h-10 w-10"></div>
            <div className="flex-1 space-y-2 py-1">
              <div className="h-4 bg-gray-300 rounded w-3/4"></div>
              <div className="h-4 bg-gray-300 rounded w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="masculine-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="h-5 w-5" />
          Recent Viewing History
        </CardTitle>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <p className="text-muted-foreground">No viewing history available.</p>
        ) : (
          <div className="space-y-3">
            {history.map((entry: any) => (
              <div key={entry.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full" />
                  <div>
                    <div className="font-medium">{entry.video?.title || 'Unknown Video'}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      {formatDate(entry.viewedAt, 'MMM d, yyyy HH:mm')}
                      {entry.duration && (
                        <>
                          <span>•</span>
                          <span>{Math.round(entry.duration / 60)}m watched</span>
                        </>
                      )}
                      {entry.completed && (
                        <>
                          <span>•</span>
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <span className="text-green-400">Completed</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                {entry.video?.isExternal && (
                  <Badge variant="secondary" className="text-xs">
                    External
                  </Badge>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface DuplicateLogProps {
  limit?: number;
}

export function DuplicateLog({ limit = 20 }: DuplicateLogProps) {
  const { data: duplicates = [], isLoading } = useQuery({
    queryKey: [`/api/duplicate-log`, limit],
  });

  if (isLoading) {
    return (
      <Card className="masculine-card">
        <CardContent className="p-4">
          <div className="animate-pulse">Loading duplicate log...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="masculine-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <X className="h-5 w-5 text-red-500" />
          Duplicate Detection Log
        </CardTitle>
      </CardHeader>
      <CardContent>
        {duplicates.length === 0 ? (
          <p className="text-muted-foreground">No duplicates detected yet.</p>
        ) : (
          <div className="space-y-3">
            {duplicates.map((entry: any) => (
              <div key={entry.id} className="flex items-start justify-between p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <div className="flex items-start gap-3">
                  <X className="h-4 w-4 text-red-500 mt-1" />
                  <div>
                    <div className="font-medium text-red-200">Duplicate URL Blocked</div>
                    <div className="text-sm text-red-300 mt-1">
                      {entry.duplicateUrl.substring(0, 60)}...
                    </div>
                    <div className="text-xs text-red-400 mt-2 flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      {formatDate(entry.attemptedAt, 'MMM d, yyyy HH:mm')}
                      {entry.originalVideo && (
                        <>
                          <span>•</span>
                          <span>Original: {entry.originalVideo.title}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <Badge variant="destructive" className="text-xs">
                  Blocked
                </Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}