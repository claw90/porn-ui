import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Play, ExternalLink, TestTube, Link as LinkIcon } from "lucide-react";

interface VideoTestPlayerProps {
  videoUrl?: string;
}

export function VideoTestPlayer({ videoUrl }: VideoTestPlayerProps) {
  const [testUrl, setTestUrl] = useState(videoUrl || "");
  const { toast } = useToast();

  // Test different embedding approaches
  const testMethods = [
    {
      name: "Direct Iframe",
      getUrl: (url: string) => url,
      description: "Load URL directly in iframe"
    },
    {
      name: "ThusVid Embed", 
      getUrl: (url: string) => {
        if (url.includes('thisvid.com')) {
          const match = url.match(/\/videos\/([^\/]+)/);
          if (match) {
            return `https://thisvid.com/embed/${match[1]}`;
          }
        }
        return url;
      },
      description: "Convert to ThusVid embed URL"
    },
    {
      name: "Proxy Method",
      getUrl: (url: string) => `https://iframe.ly/api/iframe?url=${encodeURIComponent(url)}&api_key=demo`,
      description: "Use iframe.ly proxy service"
    },
    {
      name: "No Sandbox",
      getUrl: (url: string) => url,
      description: "Direct iframe without sandbox restrictions",
      noSandbox: true
    }
  ];

  const handleTest = (method: any) => {
    const embedUrl = method.getUrl(testUrl);
    toast({
      title: `Testing: ${method.name}`,
      description: `Trying to load: ${embedUrl.substring(0, 50)}...`,
    });
  };

  return (
    <Card className="masculine-card border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TestTube className="h-5 w-5 text-primary" />
          Video Loading Diagnostics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* URL Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Test Video URL:</label>
          <Input
            value={testUrl}
            onChange={(e) => setTestUrl(e.target.value)}
            placeholder="https://thisvid.com/videos/..."
            className="border-primary/20"
          />
          <Button
            size="sm"
            onClick={() => window.open(testUrl, '_blank')}
            className="border-primary/30"
            variant="outline"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Open Original
          </Button>
        </div>

        {/* Test Methods */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {testMethods.map((method, index) => {
            const embedUrl = method.getUrl(testUrl);
            return (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-foreground">{method.name}</h4>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleTest(method)}
                    className="border-primary/30"
                  >
                    <Play className="h-3 w-3 mr-1" />
                    Test
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">{method.description}</p>
                
                {/* Test Iframe */}
                {testUrl && (
                  <div className="relative bg-black rounded overflow-hidden" style={{ height: '120px' }}>
                    <iframe
                      src={embedUrl}
                      className="w-full h-full"
                      allow="autoplay; fullscreen; picture-in-picture"
                      allowFullScreen
                      frameBorder="0"
                      sandbox={method.noSandbox ? undefined : "allow-scripts allow-same-origin allow-popups allow-forms"}
                      onLoad={() => {
                        console.log(`${method.name} loaded successfully`);
                      }}
                      onError={(e) => {
                        console.error(`${method.name} failed:`, e);
                      }}
                    />
                    
                    {/* Overlay with method info */}
                    <div className="absolute top-2 left-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                      {method.name}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Current Video Info */}
        {videoUrl && (
          <div className="p-3 bg-muted/20 rounded border border-primary/20">
            <h4 className="text-sm font-medium text-foreground mb-2">Current Video Analysis:</h4>
            <div className="space-y-1 text-xs text-muted-foreground">
              <div>URL: {videoUrl}</div>
              <div>Platform: {videoUrl.includes('thisvid.com') ? 'ThisVid' : 'Unknown'}</div>
              <div>Type: {videoUrl.includes('thisvid.com') ? 'External Adult Content' : 'Other'}</div>
              <div className="flex items-center gap-2 mt-2">
                <LinkIcon className="h-3 w-3" />
                <span>External embedding required</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}