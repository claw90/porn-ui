import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Play, 
  ExternalLink, 
  Search,
  Grid3X3,
  List,
  Star,
  Eye,
  Clock,
  Link as LinkIcon
} from "lucide-react";

interface VideoLibraryProps {
  onVideoSelect?: (video: any) => void;
  selectedVideoUrl?: string;
  className?: string;
}

export default function VideoLibrary({ 
  onVideoSelect, 
  selectedVideoUrl,
  className = "" 
}: VideoLibraryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');

  // Fetch videos from database
  const { data: videos = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/videos'],
  });

  // Filter videos based on search
  const filteredVideos = videos.filter(video => 
    video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    video.videoUrl?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    video.tags?.some((tag: string) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const extractVideoTitle = (url: string) => {
    try {
      const urlObj = new URL(url);
      const pathSegments = urlObj.pathname.split('/').filter(Boolean);
      
      if (pathSegments.length > 0) {
        const lastSegment = pathSegments[pathSegments.length - 1];
        return lastSegment.replace(/[-_]/g, ' ').replace(/\.[^/.]+$/, '').substring(0, 50);
      }
      
      return urlObj.hostname.charAt(0).toUpperCase() + urlObj.hostname.slice(1) + ' Video';
    } catch {
      return 'External Video';
    }
  };

  const getDomainFromUrl = (url: string) => {
    try {
      return new URL(url).hostname.replace('www.', '');
    } catch {
      return 'Unknown';
    }
  };

  const generateThumbnail = (url: string) => {
    const domain = getDomainFromUrl(url);
    const isThisVid = domain.includes('thisvid.com');
    const displayName = isThisVid ? 'ThisVid' : domain;
    
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="160" height="90" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#1a1a1a"/>
        <circle cx="80" cy="45" r="20" fill="#ff6b1a" opacity="0.8"/>
        <polygon points="72,35 72,55 88,45" fill="white"/>
        <text x="80" y="70" text-anchor="middle" fill="#999" font-size="8" font-family="Arial">${displayName}</text>
      </svg>
    `)}`;
  };

  if (isLoading) {
    return (
      <Card className={`masculine-card border-primary/20 ${className}`}>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground mt-4">Loading video library...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`masculine-card border-primary/20 ${className}`}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Play className="h-5 w-5 text-primary" />
            Video Library ({filteredVideos.length})
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant={viewMode === 'list' ? 'default' : 'outline'}
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              onClick={() => setViewMode('grid')}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search videos, URLs, or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 border-primary/20 focus:border-primary"
          />
        </div>
      </CardHeader>
      <CardContent>
        {filteredVideos.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No videos found</p>
          </div>
        ) : (
          <ScrollArea className="h-[600px]">
            {viewMode === 'list' ? (
              <div className="space-y-3">
                {filteredVideos.map((video) => (
                  <div
                    key={video.id}
                    className={`flex items-center gap-4 p-3 rounded-lg border transition-all cursor-pointer hover:bg-primary/5 ${
                      selectedVideoUrl === video.videoUrl 
                        ? 'border-primary bg-primary/10' 
                        : 'border-primary/20'
                    }`}
                    onClick={() => onVideoSelect?.(video)}
                  >
                    {/* Thumbnail */}
                    <div className="w-24 h-14 rounded overflow-hidden flex-shrink-0">
                      <img
                        src={generateThumbnail(video.videoUrl)}
                        alt="Video thumbnail"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Video Details */}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground truncate">
                        {video.title === 'External Video' ? 
                          extractVideoTitle(video.videoUrl) : 
                          video.title
                        }
                      </h4>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          <LinkIcon className="h-3 w-3 mr-1" />
                          {getDomainFromUrl(video.videoUrl)}
                        </Badge>
                        {video.rating > 0 && (
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                            <span className="text-xs text-muted-foreground">{video.rating}</span>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 truncate">
                        {video.videoUrl}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 w-8 p-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(video.videoUrl, '_blank');
                        }}
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredVideos.map((video) => (
                  <div
                    key={video.id}
                    className={`cursor-pointer transition-all duration-200 ${
                      selectedVideoUrl === video.videoUrl ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => onVideoSelect?.(video)}
                  >
                    <div className="space-y-2">
                      <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/10 rounded border border-primary/20 flex items-center justify-center hover:bg-primary/30 transition-colors relative overflow-hidden group">
                        <img
                          src={generateThumbnail(video.videoUrl)}
                          alt="Video thumbnail"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                          <Play className="h-8 w-8 text-white" />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-xs font-medium truncate text-foreground">
                          {video.title === 'External Video' ? 
                            extractVideoTitle(video.videoUrl).substring(0, 25) + '...' : 
                            video.title?.substring(0, 25) + (video.title?.length > 25 ? '...' : '')
                          }
                        </h4>
                        <p className="text-xs text-muted-foreground truncate">
                          {getDomainFromUrl(video.videoUrl)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}