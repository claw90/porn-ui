import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { 
  Settings as SettingsIcon,
  Database,
  Cpu,
  Film,
  Users,
  FolderOpen,
  Search,
  BarChart3,
  Server,
  Activity,
  HardDrive,
  Wifi,
  Brain,
  Eye,
  AlertTriangle,
  Trash2
} from "lucide-react";
import { Link } from "wouter";

export default function Settings() {
  // Fetch system data
  const { data: recentAnalyses = [] } = useQuery({
    queryKey: ['/api/analyses/recent/5'],
  });

  const { data: videos = [] } = useQuery({
    queryKey: ['/api/videos'],
    queryFn: () => fetch('/api/videos?limit=10').then(res => res.json())
  });

  const { data: performers = [] } = useQuery({
    queryKey: ['/api/performers'],
    queryFn: () => fetch('/api/performers?limit=10').then(res => res.json())
  });

  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold masculine-text-gradient">
          Settings & System Status
        </h1>
        <p className="text-muted-foreground mt-2">
          Configure your preferences and monitor system performance
        </p>
      </div>

      <Tabs defaultValue="system" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="system">System Status</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="data">Data Management</TabsTrigger>
        </TabsList>

        <TabsContent value="system" className="space-y-6">
          {/* System Overview */}
          <Card className="masculine-card border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                System Overview
              </CardTitle>
              <CardDescription>
                Real-time system status and resource utilization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <Film className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold text-primary">{Array.isArray(videos) ? videos.length : 0}</div>
                  <div className="text-sm text-muted-foreground">Videos</div>
                </div>
                
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <Users className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold text-primary">{Array.isArray(performers) ? performers.length : 0}</div>
                  <div className="text-sm text-muted-foreground">Performers</div>
                </div>
                
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <Search className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold text-primary">{Array.isArray(recentAnalyses) ? recentAnalyses.length : 0}</div>
                  <div className="text-sm text-muted-foreground">AI Scans</div>
                </div>
                
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <FolderOpen className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold text-primary">{Array.isArray(collections) ? collections.length : 0}</div>
                  <div className="text-sm text-muted-foreground">Collections</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Resources */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="masculine-card border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Server className="h-4 w-4 text-primary" />
                  Server Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Database</span>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                      Connected
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">API Server</span>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                      Running
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Face Recognition</span>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                      Ready
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="masculine-card border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <HardDrive className="h-4 w-4 text-primary" />
                  Storage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Video Storage</span>
                    <span className="text-sm font-medium text-primary">Available</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Face Images</span>
                    <span className="text-sm font-medium text-primary">Optimized</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Thumbnails</span>
                    <span className="text-sm font-medium text-primary">Generated</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="masculine-card border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Wifi className="h-4 w-4 text-primary" />
                  Network
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">External URLs</span>
                    <Badge variant="secondary" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                      Enabled
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Video Embedding</span>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                      Active
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Auto-play</span>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                      Enabled
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <Card className="masculine-card border-primary/20">
            <CardHeader>
              <CardTitle>User Preferences</CardTitle>
              <CardDescription>
                Customize your experience and content preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Auto-play Videos</div>
                    <div className="text-sm text-muted-foreground">Automatically start video playback</div>
                  </div>
                  <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                    Enabled
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Thumbnail Generation</div>
                    <div className="text-sm text-muted-foreground">Generate previews for videos</div>
                  </div>
                  <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                    Active
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Real-time Face Recognition</div>
                    <div className="text-sm text-muted-foreground">AI-powered face detection during playback</div>
                  </div>
                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                    Available
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <Card className="masculine-card border-primary/20">
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>
                System performance and optimization status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <BarChart3 className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-xl font-bold text-primary">98%</div>
                  <div className="text-sm text-muted-foreground">Video Load Success</div>
                </div>
                
                <div className="text-center p-4 bg-card/50 rounded-lg border border-primary/10">
                  <Cpu className="h-8 w-8 text-primary mx-auto mb-2" />
                  <div className="text-xl font-bold text-primary">Fast</div>
                  <div className="text-sm text-muted-foreground">AI Processing</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data" className="space-y-6">
          {/* Face Recognition Access */}
          <Card className="masculine-card border-orange-500/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-orange-500" />
                Advanced Backend Tools
              </CardTitle>
              <CardDescription>
                Access specialized server-side features and analysis tools
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-orange-500/30 rounded-lg bg-orange-500/5">
                <div>
                  <h3 className="font-medium text-orange-200">Face Recognition Analysis</h3>
                  <p className="text-sm text-orange-300/80">
                    Server-side face detection and matching across video content using Python backend
                  </p>
                </div>
                <Link href="/face-recognition">
                  <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                    <Eye className="h-4 w-4 mr-2" />
                    Open Tool
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="masculine-card border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5 text-primary" />
                Data Management
              </CardTitle>
              <CardDescription>
                Manage your content library and data storage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button variant="outline" className="w-full border-primary/30">
                  <Database className="h-4 w-4 mr-2" />
                  Export Library Data
                </Button>
                
                <Button variant="outline" className="w-full border-primary/30">
                  <HardDrive className="h-4 w-4 mr-2" />
                  Clear Cache
                </Button>
                
                <Button variant="outline" className="w-full border-primary/30">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}