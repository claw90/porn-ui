import React from 'react';
import TestDiscoveryButton from '@/components/TestDiscoveryButton';
import { InternetVideoSearch } from '@/components/InternetVideoSearch';
import { SITE_TEXT } from '@/config/siteText';

export default function Discovery() {
  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold collection-text-gradient">
          {SITE_TEXT.discovery.pageTitle}
        </h1>
        <p className="text-muted-foreground">
          {SITE_TEXT.discovery.pageSubtitle}
        </p>
      </div>

      {/* Internet Video Search - Main Feature */}
      <InternetVideoSearch />

      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">
            Or try automated discovery
          </span>
        </div>
      </div>

      {/* Test Discovery Button - Secondary Feature */}
      <TestDiscoveryButton />
    </div>
  );
}