import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuCheckboxItem } from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Play, Heart, Bookmark, Star, MoreVertical, Search, Filter, Upload, Plus, Eye, Clock, HardDrive, Link, Grid3X3, List, SlidersHorizontal, Calendar, Tag, Users, Folder, ChevronDown, X } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { VideoUrlForm } from "@/components/VideoUrlForm";
import { BulkUrlImport } from "@/components/BulkUrlImport";
import type { Video, Collection, Performer } from "@shared/schema";

export default function Library() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCollection, setSelectedCollection] = useState<string>("all");
  const [sortBy, setSortBy] = useState("recent");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedPerformers, setSelectedPerformers] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [durationFilter, setDurationFilter] = useState<[number, number]>([0, 120]);
  const [ratingFilter, setRatingFilter] = useState<number>(0);
  const [showExternalOnly, setShowExternalOnly] = useState(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const { toast } = useToast();

  // Fetch videos with search/filter
  const { data: videos = [], isLoading: videosLoading, error: videosError } = useQuery({
    queryKey: ['/api/videos'],
  });

  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
  });

  const { data: performers = [] } = useQuery({
    queryKey: ['/api/performers'],
  });

  // Format duration from seconds to MM:SS
  const formatDuration = (seconds?: number) => {
    if (!seconds) return "0:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Format file size
  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "0 MB";
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  // Toggle favorite status
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ videoId, isFavorite }: { videoId: string; isFavorite: boolean }) => {
      return apiRequest(`/api/videos/${videoId}`, {
        method: 'PATCH',
        body: JSON.stringify({ isFavorite: !isFavorite }),
        headers: { "Content-Type": "application/json" }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Updated", description: "Video favorite status updated" });
    }
  });

  // Toggle bookmark status
  const toggleBookmarkMutation = useMutation({
    mutationFn: async ({ videoId, isBookmarked }: { videoId: string; isBookmarked: boolean }) => {
      return apiRequest(`/api/videos/${videoId}`, {
        method: 'PATCH',
        body: JSON.stringify({ isBookmarked: !isBookmarked }),
        headers: { "Content-Type": "application/json" }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Updated", description: "Video bookmark status updated" });
    }
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Video Library</h2>
          <p className="text-muted-foreground">
            Manage your adult content collection with advanced organization and face recognition
          </p>
        </div>
        <Button>
          <Upload className="mr-2 h-4 w-4" />
          Upload Video
        </Button>
      </div>

      {/* Enhanced Search and Filter Bar */}
      <div className="space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search videos, performers, tags, categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 masculine-input"
            />
          </div>
          
          {/* View Mode Toggle */}
          <div className="flex items-center border border-primary/20 rounded-lg p-1 bg-muted/30">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className={viewMode === "grid" ? "masculine-gradient" : ""}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className={viewMode === "list" ? "masculine-gradient" : ""}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>

          {/* Quick Filter Options */}
          <div className="flex gap-2">
            <Button
              variant={showFavoritesOnly ? "default" : "outline"}
              size="sm"
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className={showFavoritesOnly ? "masculine-gradient" : "border-primary/30 hover:bg-primary/10"}
            >
              <Heart className="h-4 w-4 mr-1" />
              Favorites
            </Button>
            <Button
              variant={showExternalOnly ? "default" : "outline"}
              size="sm"
              onClick={() => setShowExternalOnly(!showExternalOnly)}
              className={showExternalOnly ? "masculine-gradient" : "border-primary/30 hover:bg-primary/10"}
            >
              <Link className="h-4 w-4 mr-1" />
              URLs
            </Button>
          </div>
        </div>

        {/* Advanced Filters Row */}
        <div className="flex flex-wrap gap-3">
          <Select value={selectedCollection} onValueChange={setSelectedCollection}>
            <SelectTrigger className="w-[180px] border-primary/20 focus:border-primary">
              <Folder className="h-4 w-4 mr-2" />
              <SelectValue placeholder="All Collections" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Collections</SelectItem>
              {Array.isArray(collections) && collections.map((collection: Collection) => (
                <SelectItem key={collection.id} value={collection.id}>
                  {collection.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Advanced Filters Dropdown */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="border-primary/30 hover:bg-primary/10">
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                Advanced Filters
                {activeFilters.length > 0 && (
                  <Badge variant="secondary" className="ml-2 h-5">
                    {activeFilters.length}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 masculine-card border-primary/20">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Duration Range (minutes)</Label>
                  <Slider
                    value={durationFilter}
                    onValueChange={(value) => setDurationFilter(value as [number, number])}
                    max={120}
                    min={0}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{durationFilter[0]}m</span>
                    <span>{durationFilter[1]}m+</span>
                  </div>
                </div>

                <Separator className="bg-primary/20" />

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Minimum Rating</Label>
                  <Slider
                    value={[ratingFilter]}
                    onValueChange={(value) => setRatingFilter(value[0])}
                    max={5}
                    min={0}
                    step={0.5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Any</span>
                    <span>{ratingFilter}+ stars</span>
                  </div>
                </div>

                <Separator className="bg-primary/20" />

                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setDurationFilter([0, 120]);
                      setRatingFilter(0);
                      setSelectedPerformers([]);
                      setSelectedTags([]);
                      setSelectedCategories([]);
                      setActiveFilters([]);
                    }}
                    className="border-primary/30"
                  >
                    Clear All
                  </Button>
                  <Button 
                    size="sm"
                    className="masculine-gradient"
                    onClick={() => {
                      // Apply filters logic here
                      const filters = [];
                      if (durationFilter[0] > 0 || durationFilter[1] < 120) filters.push('duration');
                      if (ratingFilter > 0) filters.push('rating');
                      setActiveFilters(filters);
                    }}
                  >
                    Apply Filters
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px] border-primary/20 focus:border-primary">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="duration">By Duration</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="views">Most Viewed</SelectItem>
              <SelectItem value="title">Alphabetical</SelectItem>
              <SelectItem value="size">File Size</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Active Filters Display */}
        {(activeFilters.length > 0 || selectedPerformers.length > 0 || selectedTags.length > 0 || selectedCategories.length > 0) && (
          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            {activeFilters.map((filter) => (
              <Badge key={filter} variant="secondary" className="bg-primary/10 text-primary border-primary/30">
                {filter}
                <X 
                  className="h-3 w-3 ml-1 cursor-pointer" 
                  onClick={() => setActiveFilters(activeFilters.filter(f => f !== filter))}
                />
              </Badge>
            ))}
            {selectedPerformers.map((performer) => (
              <Badge key={performer} variant="secondary" className="bg-primary/10 text-primary border-primary/30">
                {performer}
                <X 
                  className="h-3 w-3 ml-1 cursor-pointer" 
                  onClick={() => setSelectedPerformers(selectedPerformers.filter(p => p !== performer))}
                />
              </Badge>
            ))}
            {(activeFilters.length > 0 || selectedPerformers.length > 0) && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  setActiveFilters([]);
                  setSelectedPerformers([]);
                  setSelectedTags([]);
                  setSelectedCategories([]);
                }}
                className="text-muted-foreground hover:text-primary"
              >
                Clear all
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Quick Filters */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Videos</TabsTrigger>
          <TabsTrigger value="add-url">Add URL</TabsTrigger>
          <TabsTrigger value="bulk-import">Bulk Import</TabsTrigger>
          <TabsTrigger value="favorites">Favorites</TabsTrigger>
          <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
          <TabsTrigger value="recent">Recently Added</TabsTrigger>
          <TabsTrigger value="watched">Recently Watched</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {/* Video Display */}
          {videosLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-4">Loading videos...</p>
            </div>
          ) : videos.length === 0 ? (
            <Card className="masculine-card border-primary/20">
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">No videos found. Upload some videos or add URLs to get started.</p>
              </CardContent>
            </Card>
          ) : (
            <div>
              {viewMode === "list" ? (
                <div className="space-y-3">
                  {videos.map((video) => (
                    <Card key={video.id} className="masculine-card border-primary/20 hover:border-primary/40 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          {/* Thumbnail */}
                          <div className="w-24 h-14 rounded overflow-hidden flex-shrink-0 bg-gradient-to-br from-primary/20 to-primary/10">
                            {video.isExternal && video.videoUrl ? (
                              <img
                                src={`data:image/svg+xml;base64,${btoa(`
                                  <svg width="160" height="90" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="100%" height="100%" fill="#1a1a1a"/>
                                    <circle cx="80" cy="45" r="20" fill="#ff6b1a" opacity="0.8"/>
                                    <polygon points="72,35 72,55 88,45" fill="white"/>
                                    <text x="80" y="70" text-anchor="middle" fill="#999" font-size="8" font-family="Arial">${video.videoUrl.includes('thisvid.com') ? 'ThisVid' : 'Video'}</text>
                                  </svg>
                                `)}`}
                                alt="Video thumbnail"
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Play className="h-6 w-6 text-primary" />
                              </div>
                            )}
                          </div>

                          {/* Video Details */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-foreground truncate">
                                  {video.title === 'External Video' && video.videoUrl ? 
                                    (() => {
                                      try {
                                        const url = new URL(video.videoUrl);
                                        const pathSegments = url.pathname.split('/').filter(Boolean);
                                        if (pathSegments.length > 0) {
                                          const lastSegment = pathSegments[pathSegments.length - 1];
                                          return lastSegment.replace(/[-_]/g, ' ').substring(0, 50);
                                        }
                                        return url.hostname.replace('www.', '') + ' Video';
                                      } catch {
                                        return 'External Video';
                                      }
                                    })() : 
                                    video.title
                                  }
                                </h4>
                                <div className="flex items-center gap-2 mt-1">
                                  {video.isExternal && (
                                    <Badge variant="secondary" className="text-xs">
                                      <Link className="h-3 w-3 mr-1" />
                                      {(() => {
                                        try {
                                          return new URL(video.videoUrl).hostname.replace('www.', '');
                                        } catch {
                                          return 'External';
                                        }
                                      })()}
                                    </Badge>
                                  )}
                                  {video.rating > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                                      <span className="text-xs text-muted-foreground">{video.rating}</span>
                                    </div>
                                  )}
                                  {video.viewCount > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Eye className="h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">{video.viewCount}</span>
                                    </div>
                                  )}
                                </div>
                                {video.videoUrl && (
                                  <p className="text-xs text-muted-foreground mt-1 truncate max-w-md">
                                    {video.videoUrl}
                                  </p>
                                )}
                              </div>
                              
                              {/* Action Buttons */}
                              <div className="flex items-center gap-1 ml-4">
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                  <Play className="h-4 w-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => video.videoUrl && window.open(video.videoUrl, '_blank')}
                                >
                                  <Link className="h-4 w-4" />
                                </Button>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end" className="masculine-card border-primary/20">
                                    <DropdownMenuItem onClick={() => toggleFavoriteMutation.mutate({ videoId: video.id, isFavorite: video.isFavorite })}>
                                      <Heart className={`mr-2 h-4 w-4 ${video.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                                      {video.isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => toggleBookmarkMutation.mutate({ videoId: video.id, isBookmarked: video.isBookmarked })}>
                                      <Bookmark className={`mr-2 h-4 w-4 ${video.isBookmarked ? 'fill-blue-500 text-blue-500' : ''}`} />
                                      {video.isBookmarked ? 'Remove Bookmark' : 'Add Bookmark'}
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {videos.map((video) => (
                    <Card key={video.id} className="masculine-card border-primary/20 hover:border-primary/40 transition-colors cursor-pointer">
                      <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/10 relative overflow-hidden">
                        {video.isExternal && video.videoUrl ? (
                          <img
                            src={`data:image/svg+xml;base64,${btoa(`
                              <svg width="160" height="90" xmlns="http://www.w3.org/2000/svg">
                                <rect width="100%" height="100%" fill="#1a1a1a"/>
                                <circle cx="80" cy="45" r="20" fill="#ff6b1a" opacity="0.8"/>
                                <polygon points="72,35 72,55 88,45" fill="white"/>
                                <text x="80" y="70" text-anchor="middle" fill="#999" font-size="8" font-family="Arial">${video.videoUrl.includes('thisvid.com') ? 'ThisVid' : 'Video'}</text>
                              </svg>
                            `)}`}
                            alt="Video thumbnail"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Play className="h-8 w-8 text-primary" />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-black/0 hover:bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-all">
                          <Play className="h-10 w-10 text-white" />
                        </div>
                      </div>
                      <CardContent className="p-3">
                        <h4 className="text-sm font-medium truncate text-foreground">
                          {video.title === 'External Video' && video.videoUrl ? 
                            (() => {
                              try {
                                const url = new URL(video.videoUrl);
                                const pathSegments = url.pathname.split('/').filter(Boolean);
                                if (pathSegments.length > 0) {
                                  const lastSegment = pathSegments[pathSegments.length - 1];
                                  return lastSegment.replace(/[-_]/g, ' ').substring(0, 30) + '...';
                                }
                                return url.hostname.replace('www.', '') + ' Video';
                              } catch {
                                return 'External Video';
                              }
                            })() : 
                            (video.title?.substring(0, 30) + (video.title?.length > 30 ? '...' : ''))
                          }
                        </h4>
                        <div className="flex items-center gap-1 mt-1">
                          {video.isExternal && (
                            <Badge variant="secondary" className="text-xs h-4 px-1">URL</Badge>
                          )}
                          {video.rating > 0 && (
                            <div className="flex items-center gap-1">
                              <Star className="h-2 w-2 fill-yellow-500 text-yellow-500" />
                              <span className="text-xs text-muted-foreground">{video.rating}</span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="add-url" className="space-y-4">
          <VideoUrlForm />
        </TabsContent>

        <TabsContent value="bulk-import" className="space-y-4">
          <BulkUrlImport />
        </TabsContent>

        <TabsContent value="favorites" className="space-y-4">
          <p className="text-muted-foreground">Favorite videos will appear here.</p>
        </TabsContent>

        <TabsContent value="bookmarks" className="space-y-4">
          <p className="text-muted-foreground">Bookmarked videos will appear here.</p>
        </TabsContent>

        <TabsContent value="recent" className="space-y-4">
          <p className="text-muted-foreground">Recently added videos will appear here.</p>
        </TabsContent>

        <TabsContent value="watched" className="space-y-4">
          <p className="text-muted-foreground">Recently watched videos will appear here.</p>
        </TabsContent>
      </Tabs>
    </div>
  );
}
                      <div className="absolute bottom-3 left-3">
                        <div className="flex gap-2">
                          <Badge variant="secondary" className="text-xs bg-black/60 border-primary/30">
                            <Clock className="w-3 h-3 mr-1" />
                            {formatDuration(video.duration || 0)}
                          </Badge>
                          {video.isExternal && (
                            <Badge variant="secondary" className="text-xs bg-black/60 border-primary/30">
                              <Link className="w-3 h-3" />
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="absolute bottom-3 right-3">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="secondary"
                            className="h-8 w-8 p-0 bg-black/60 hover:bg-primary/20 border-primary/30"
                            onClick={() => toggleFavoriteMutation.mutate({ videoId: video.id, isFavorite: video.isFavorite || false })}
                          >
                            <Heart className={`h-4 w-4 ${video.isFavorite ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            className="h-8 w-8 p-0 bg-black/60 hover:bg-primary/20 border-primary/30"
                            onClick={() => toggleBookmarkMutation.mutate({ videoId: video.id, isBookmarked: video.isBookmarked || false })}
                          >
                            <Bookmark className={`h-4 w-4 ${video.isBookmarked ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="absolute top-3 right-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button 
                              variant="secondary" 
                              size="sm" 
                              className="h-8 w-8 p-0 bg-black/60 hover:bg-primary/20 border-primary/30"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="masculine-card border-primary/20">
                            <DropdownMenuItem className="hover:bg-primary/10">
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem className="hover:bg-primary/10">
                              <Folder className="h-4 w-4 mr-2" />
                              Add to Collection
                            </DropdownMenuItem>
                            <DropdownMenuItem className="hover:bg-primary/10">
                              <Users className="h-4 w-4 mr-2" />
                              Run Face Analysis
                            </DropdownMenuItem>
                            <DropdownMenuSeparator className="bg-primary/20" />
                            <DropdownMenuItem className="text-destructive hover:bg-destructive/10">
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <h3 className="font-semibold text-sm leading-tight line-clamp-2 flex-1 hover:text-primary transition-colors cursor-pointer">
                          {video.title || video.originalName}
                        </h3>
                      </div>
                      
                      {video.performers && video.performers.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {video.performers.slice(0, 2).map((performer) => (
                            <Badge 
                              key={performer} 
                              variant="outline" 
                              className="text-xs border-primary/30 hover:bg-primary/10 cursor-pointer"
                              onClick={() => setSelectedPerformers([...selectedPerformers, performer])}
                            >
                              <Users className="w-3 h-3 mr-1" />
                              {performer}
                            </Badge>
                          ))}
                          {video.performers.length > 2 && (
                            <Badge variant="outline" className="text-xs border-primary/30">
                              +{video.performers.length - 2} more
                            </Badge>
                          )}
                        </div>
                      )}

                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-3">
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {video.viewCount || 0}
                          </span>
                          {!video.isExternal && (
                            <span className="flex items-center gap-1">
                              <HardDrive className="w-3 h-3" />
                              {formatFileSize(video.fileSize || 0)}
                            </span>
                          )}
                        </div>
                        {video.rating && video.rating > 0 && (
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-primary text-primary" />
                            <span>{video.rating}</span>
                          </div>
                        )}
                      </div>

                      {video.tags && video.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {video.tags.slice(0, 3).map((tag) => (
                            <Badge 
                              key={tag} 
                              variant="secondary" 
                              className="text-xs filter-badge cursor-pointer"
                              onClick={() => setSelectedTags([...selectedTags, tag])}
                            >
                              <Tag className="w-3 h-3 mr-1" />
                              {tag}
                            </Badge>
                          ))}
                          {video.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{video.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {Array.isArray(videos) && videos.map((video: Video) => (
                <div key={video.id} className="list-view-item group">
                  <div className="w-32 h-20 video-thumbnail rounded-lg flex-shrink-0">
                    {video.thumbnailPath ? (
                      <img 
                        src={video.thumbnailPath} 
                        alt={video.title || video.originalName || ''}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-full dark-gradient rounded-lg flex items-center justify-center">
                        {video.isExternal ? (
                          <Link className="h-6 w-6 text-primary" />
                        ) : (
                          <Play className="h-6 w-6 text-primary/70" />
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <h3 className="font-semibold text-sm line-clamp-1 hover:text-primary transition-colors cursor-pointer">
                        {video.title || video.originalName}
                      </h3>
                      <div className="flex items-center gap-2 ml-4">
                        <Badge variant="secondary" className="text-xs">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatDuration(video.duration || 0)}
                        </Badge>
                        {video.isExternal && (
                          <Badge variant="secondary" className="text-xs">
                            <Link className="w-3 h-3" />
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {video.viewCount || 0} views
                      </span>
                      {!video.isExternal && (
                        <span className="flex items-center gap-1">
                          <HardDrive className="w-3 h-3" />
                          {formatFileSize(video.fileSize || 0)}
                        </span>
                      )}
                      {video.rating && video.rating > 0 && (
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-primary text-primary" />
                          {video.rating}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 mt-2">
                      {video.performers && video.performers.slice(0, 3).map((performer) => (
                        <Badge 
                          key={performer} 
                          variant="outline" 
                          className="text-xs border-primary/30 hover:bg-primary/10 cursor-pointer"
                        >
                          {performer}
                        </Badge>
                      ))}
                      {video.tags && video.tags.slice(0, 2).map((tag) => (
                        <Badge 
                          key={tag} 
                          variant="secondary" 
                          className="text-xs filter-badge cursor-pointer"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="h-8 w-8 p-0"
                      onClick={() => toggleFavoriteMutation.mutate({ videoId: video.id, isFavorite: video.isFavorite || false })}
                    >
                      <Heart className={`h-4 w-4 ${video.isFavorite ? 'fill-primary text-primary' : ''}`} />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="h-8 w-8 p-0"
                      onClick={() => toggleBookmarkMutation.mutate({ videoId: video.id, isBookmarked: video.isBookmarked || false })}
                    >
                      <Bookmark className={`h-4 w-4 ${video.isBookmarked ? 'fill-primary text-primary' : ''}`} />
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="secondary" size="sm" className="h-8 w-8 p-0">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="masculine-card border-primary/20">
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Add to Collection</DropdownMenuItem>
                        <DropdownMenuItem>Run Face Analysis</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Add URL Tab */}
        <TabsContent value="add-url" className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <VideoUrlForm onSuccess={() => {
              // Refresh videos list after successful URL addition
              queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
            }} />
          </div>
        </TabsContent>

        {/* Bulk Import Tab */}
        <TabsContent value="bulk-import" className="space-y-6">
          <div className="max-w-4xl mx-auto">
            <BulkUrlImport onComplete={() => {
              // Refresh videos list after bulk import
              queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
            }} />
          </div>
        </TabsContent>



        {/* Other tab contents would be similar but filtered */}
        <TabsContent value="favorites">
          <div className="text-center py-12">
            <Heart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No favorite videos yet</h3>
            <p className="text-muted-foreground">Mark videos as favorites to see them here</p>
          </div>
        </TabsContent>

        <TabsContent value="bookmarks">
          <div className="text-center py-12">
            <Bookmark className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No bookmarked videos yet</h3>
            <p className="text-muted-foreground">Bookmark videos to watch later</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}