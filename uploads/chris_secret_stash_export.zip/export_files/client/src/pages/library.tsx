import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuCheckboxItem } from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Play, Heart, Bookmark, Star, MoreVertical, Search, Filter, Upload, Plus, Eye, Clock, HardDrive, Link, Grid3X3, List, SlidersHorizontal, Calendar, Tag, Users, Folder, ChevronDown, X, Wand2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { VideoUrlForm } from "@/components/VideoUrlForm";
import { BulkUrlImport } from "@/components/BulkUrlImport";
import SimilarVideos from "@/components/SimilarVideos";
import type { Video, Collection, Performer } from "@shared/schema";

// Thumbnail component with fallback
function ThumbnailImage({ video, size }: { video: any; size: 'small' | 'large' }) {
  const [imageError, setImageError] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  if (imageError || !video.id) {
    // Show placeholder when image fails to load
    const isSmall = size === 'small';
    const playButtonSize = isSmall ? 'w-8 h-8' : 'w-12 h-12';
    const iconSize = isSmall ? 'h-4 w-4' : 'h-6 w-6';
    const textSize = isSmall ? 'text-[8px]' : 'text-sm';
    const domainTextSize = isSmall ? 'text-[6px]' : 'text-xs';

    const platformName = video.videoUrl && video.videoUrl.includes('thisvid.com') ? 'ThisVid' : 
                        video.videoUrl && video.videoUrl.includes('pornhub.com') ? 'PornHub' :
                        video.videoUrl && video.videoUrl.includes('xvideos.com') ? 'XVideos' :
                        video.videoUrl ? 'External' : 'Local';

    const domainName = video.videoUrl ? (() => {
      try {
        return new URL(video.videoUrl).hostname.replace('www.', '');
      } catch {
        return 'External';
      }
    })() : 'Local Video';

    return (
      <div className="w-full h-full bg-gradient-to-br from-zinc-900 to-zinc-800 flex flex-col items-center justify-center text-center relative">
        <div className={`${playButtonSize} rounded-full bg-orange-500/80 flex items-center justify-center ${isSmall ? 'mb-1' : 'mb-2'}`}>
          <Play className={`${iconSize} text-white fill-white ml-0.5`} />
        </div>
        <div className={`${textSize} text-gray-400 font-medium ${isSmall ? '' : 'mb-1'}`}>
          {platformName}
        </div>
        <div className={`${domainTextSize} text-gray-500 truncate w-full ${isSmall ? 'px-1' : 'px-2'}`}>
          {domainName}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative">
      {!imageLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-zinc-800 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
        </div>
      )}
      <img
        src={`/api/videos/${video.id}/thumbnail?t=${Date.now()}`}
        alt="Video thumbnail"
        className={`w-full h-full object-cover transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
        onLoad={() => setImageLoaded(true)}
        onError={() => setImageError(true)}
      />
    </div>
  );
}

export default function Library() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCollection, setSelectedCollection] = useState<string>("all");
  const [sortBy, setSortBy] = useState("recent");
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");
  const [selectedPerformers, setSelectedPerformers] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [durationFilter, setDurationFilter] = useState<[number, number]>([0, 120]);
  const [ratingFilter, setRatingFilter] = useState<number>(0);
  const [showExternalOnly, setShowExternalOnly] = useState(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showSimilarVideos, setShowSimilarVideos] = useState(false);
  const { toast } = useToast();

  // Fetch videos with search/filter
  const { data: allVideos = [], isLoading: videosLoading, error: videosError } = useQuery<Video[]>({
    queryKey: ['/api/videos'],
  });

  // Apply filters and search
  const filteredVideos = allVideos.filter(video => {
    // Search filter
    if (searchQuery) {
      const searchTerm = searchQuery.toLowerCase();
      const matchesTitle = video.title?.toLowerCase().includes(searchTerm);
      const matchesUrl = video.videoUrl?.toLowerCase().includes(searchTerm);
      const matchesTags = video.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm));
      
      if (!matchesTitle && !matchesUrl && !matchesTags) {
        return false;
      }
    }

    // Favorites filter
    if (showFavoritesOnly && !video.isFavorite) {
      return false;
    }

    // External only filter
    if (showExternalOnly && !video.isExternal) {
      return false;
    }

    // Tags filter
    if (selectedTags.length > 0) {
      const hasMatchingTag = selectedTags.some(tag => 
        video.tags?.some((videoTag: string) => videoTag.toLowerCase().includes(tag.toLowerCase()))
      );
      if (!hasMatchingTag) {
        return false;
      }
    }

    // Categories filter
    if (selectedCategories.length > 0) {
      const hasMatchingCategory = selectedCategories.some(category => 
        video.categories?.some((videoCategory: string) => videoCategory.toLowerCase().includes(category.toLowerCase()))
      );
      if (!hasMatchingCategory) {
        return false;
      }
    }

    // Duration filter (convert seconds to minutes)
    if (video.duration) {
      const durationMinutes = video.duration / 60;
      if (durationMinutes < durationFilter[0] || durationMinutes > durationFilter[1]) {
        return false;
      }
    }

    // Rating filter
    if (ratingFilter > 0 && (video.rating || 0) < ratingFilter) {
      return false;
    }

    return true;
  });

  // Sort videos
  const sortedVideos = [...filteredVideos].sort((a, b) => {
    switch (sortBy) {
      case 'title':
        return (a.title || '').localeCompare(b.title || '');
      case 'rating':
        return (b.rating || 0) - (a.rating || 0);
      case 'duration':
        return (b.duration || 0) - (a.duration || 0);
      case 'views':
        return (b.viewCount || 0) - (a.viewCount || 0);
      case 'recent':
      default:
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    }
  });

  const videos = sortedVideos;

  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
  });

  const { data: performers = [] } = useQuery({
    queryKey: ['/api/performers'],
  });

  // Format duration from seconds to MM:SS
  const formatDuration = (seconds?: number) => {
    if (!seconds) return "0:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Format file size
  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "0 MB";
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  // Toggle favorite status
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ videoId, isFavorite }: { videoId: string; isFavorite: boolean }) => {
      return apiRequest(`/api/videos/${videoId}`, {
        method: 'PATCH',
        body: JSON.stringify({ isFavorite: !isFavorite }),
        headers: { "Content-Type": "application/json" }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Updated", description: "Video favorite status updated" });
    }
  });

  // Toggle bookmark status
  const toggleBookmarkMutation = useMutation({
    mutationFn: async ({ videoId, isBookmarked }: { videoId: string; isBookmarked: boolean }) => {
      return apiRequest(`/api/videos/${videoId}`, {
        method: 'PATCH',
        body: JSON.stringify({ isBookmarked: !isBookmarked }),
        headers: { "Content-Type": "application/json" }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Updated", description: "Video bookmark status updated" });
    }
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Video Library</h2>
          <p className="text-muted-foreground">
            Manage your adult content collection with advanced organization and face recognition
          </p>
        </div>
        <Button>
          <Upload className="mr-2 h-4 w-4" />
          Upload Video
        </Button>
      </div>

      {/* Enhanced Search and Filter Bar */}
      <div className="space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search videos, performers, tags, categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 masculine-input"
            />
          </div>
          
          {/* View Mode Toggle */}
          <div className="flex items-center border border-primary/20 rounded-lg p-1 bg-muted/30">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className={viewMode === "grid" ? "masculine-gradient" : ""}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className={viewMode === "list" ? "masculine-gradient" : ""}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>

          {/* Quick Filter Options */}
          <div className="flex gap-2">
            <Button
              variant={showFavoritesOnly ? "default" : "outline"}
              size="sm"
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className={showFavoritesOnly ? "masculine-gradient" : "border-primary/30 hover:bg-primary/10"}
            >
              <Heart className="h-4 w-4 mr-1" />
              Favorites
            </Button>
            <Button
              variant={showExternalOnly ? "default" : "outline"}
              size="sm"
              onClick={() => setShowExternalOnly(!showExternalOnly)}
              className={showExternalOnly ? "masculine-gradient" : "border-primary/30 hover:bg-primary/10"}
            >
              <Link className="h-4 w-4 mr-1" />
              URLs
            </Button>
          </div>
        </div>

        {/* Advanced Filters */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="border-primary/30 hover:bg-primary/10">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Advanced Filters
              {activeFilters.length > 0 && (
                <Badge variant="secondary" className="ml-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
                  {activeFilters.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 masculine-card border-primary/20" align="start">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Advanced Filters</h4>
                {activeFilters.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSelectedTags([]);
                      setSelectedCategories([]);
                      setSelectedPerformers([]);
                      setDurationFilter([0, 120]);
                      setRatingFilter(0);
                      setActiveFilters([]);
                    }}
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {/* Tags Filter */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Tags</Label>
                <div className="flex flex-wrap gap-1">
                  {['gay', 'muscle', 'bear', 'twink', 'daddy', 'amateur', 'bareback'].map((tag) => (
                    <Badge
                      key={tag}
                      variant={selectedTags.includes(tag) ? "default" : "outline"}
                      className={`cursor-pointer text-xs ${selectedTags.includes(tag) ? 'masculine-gradient' : 'border-primary/30 hover:bg-primary/10'}`}
                      onClick={() => {
                        if (selectedTags.includes(tag)) {
                          setSelectedTags(selectedTags.filter(t => t !== tag));
                        } else {
                          setSelectedTags([...selectedTags, tag]);
                        }
                      }}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Categories Filter */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Categories</Label>
                <div className="flex flex-wrap gap-1">
                  {['discovered', 'favorites', 'imported', 'local', 'premium'].map((category) => (
                    <Badge
                      key={category}
                      variant={selectedCategories.includes(category) ? "default" : "outline"}
                      className={`cursor-pointer text-xs ${selectedCategories.includes(category) ? 'masculine-gradient' : 'border-primary/30 hover:bg-primary/10'}`}
                      onClick={() => {
                        if (selectedCategories.includes(category)) {
                          setSelectedCategories(selectedCategories.filter(c => c !== category));
                        } else {
                          setSelectedCategories([...selectedCategories, category]);
                        }
                      }}
                    >
                      {category}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Duration Filter */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Duration (minutes)</Label>
                <div className="px-2">
                  <Slider
                    value={durationFilter}
                    onValueChange={(value: number[]) => setDurationFilter(value as [number, number])}
                    max={120}
                    min={0}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>{durationFilter[0]}m</span>
                    <span>{durationFilter[1]}m</span>
                  </div>
                </div>
              </div>

              {/* Rating Filter */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Minimum Rating</Label>
                <div className="px-2">
                  <Slider
                    value={[ratingFilter]}
                    onValueChange={(value) => setRatingFilter(value[0])}
                    max={5}
                    min={0}
                    step={0.5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>0★</span>
                    <span>{ratingFilter}★</span>
                    <span>5★</span>
                  </div>
                </div>
              </div>

              {/* Sort Options */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Sort By</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full border-primary/30">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="masculine-card border-primary/20">
                    <SelectItem value="recent">Recently Added</SelectItem>
                    <SelectItem value="title">Title (A-Z)</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="duration">Duration</SelectItem>
                    <SelectItem value="views">Most Viewed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Videos</TabsTrigger>
          <TabsTrigger value="add-url">Add URL</TabsTrigger>
          <TabsTrigger value="bulk-import">Bulk Import</TabsTrigger>
          <TabsTrigger value="favorites">Favorites</TabsTrigger>
          <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
          <TabsTrigger value="recent">Recently Added</TabsTrigger>
          <TabsTrigger value="watched">Recently Watched</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {/* Video Display */}
          {videosLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-4">Loading videos...</p>
            </div>
          ) : !videos || videos.length === 0 ? (
            <Card className="masculine-card border-primary/20">
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">No videos found. Upload some videos or add URLs to get started.</p>
              </CardContent>
            </Card>
          ) : (
            <div>
              {viewMode === "list" ? (
                <div className="space-y-3">
                  {videos.map((video) => (
                    <Card key={video.id} className="masculine-card border-primary/20 hover:border-primary/40 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          {/* Thumbnail */}
                          <div 
                            className="w-24 h-14 rounded overflow-hidden flex-shrink-0 bg-gradient-to-br from-primary/20 to-primary/10 cursor-pointer hover:ring-2 hover:ring-primary/50 transition-all"
                            onClick={() => {
                              // Navigate to Playing Now page with this video
                              window.location.href = `/?video=${video.id}`;
                            }}
                          >
                            <img
                              src={`data:image/svg+xml;base64,${btoa(`
                                <svg width="96" height="56" xmlns="http://www.w3.org/2000/svg">
                                  <defs>
                                    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                                      <stop offset="0%" style="stop-color:#${video.videoUrl?.includes('thisvid') ? 'FF6B35' : video.videoUrl?.includes('pornhub') ? 'FFA500' : video.videoUrl?.includes('xvideos') ? 'FF0000' : '6B46C1'};stop-opacity:0.8" />
                                      <stop offset="100%" style="stop-color:#1a1a1a;stop-opacity:1" />
                                    </linearGradient>
                                  </defs>
                                  <rect width="100%" height="100%" fill="url(#grad)"/>
                                  <circle cx="48" cy="28" r="10" fill="rgba(255,255,255,0.9)"/>
                                  <polygon points="44,24 44,32 52,28" fill="#1a1a1a"/>
                                  <text x="48" y="48" text-anchor="middle" fill="white" font-family="Arial" font-size="8" font-weight="bold">${video.videoUrl?.includes('thisvid') ? 'THISVID' : video.videoUrl?.includes('pornhub') ? 'PORNHUB' : video.videoUrl?.includes('xvideos') ? 'XVIDEOS' : 'VIDEO'}</text>
                                </svg>
                              `)}`}
                              alt="Video thumbnail"
                              className="w-full h-full object-cover"
                            />
                          </div>

                          {/* Video Details */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-foreground truncate">
                                  {video.title === 'External Video' && video.videoUrl ? 
                                    (() => {
                                      try {
                                        const url = new URL(video.videoUrl);
                                        const pathSegments = url.pathname.split('/').filter(Boolean);
                                        if (pathSegments.length > 0) {
                                          const lastSegment = pathSegments[pathSegments.length - 1];
                                          return lastSegment.replace(/[-_]/g, ' ').substring(0, 50);
                                        }
                                        return url.hostname.replace('www.', '') + ' Video';
                                      } catch {
                                        return 'External Video';
                                      }
                                    })() : 
                                    video.title
                                  }
                                </h4>
                                <div className="flex items-center gap-2 mt-1">
                                  {video.isExternal && (
                                    <Badge variant="secondary" className="text-xs">
                                      <Link className="h-3 w-3 mr-1" />
                                      {(() => {
                                        try {
                                          return video.videoUrl ? new URL(video.videoUrl).hostname.replace('www.', '') : 'External';
                                        } catch {
                                          return 'External';
                                        }
                                      })()}
                                    </Badge>
                                  )}
                                  {(video.rating || 0) > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                                      <span className="text-xs text-muted-foreground">{video.rating}</span>
                                    </div>
                                  )}
                                  {(video.viewCount || 0) > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Eye className="h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">{video.viewCount}</span>
                                    </div>
                                  )}
                                </div>
                                {video.videoUrl && (
                                  <p className="text-xs text-muted-foreground mt-1 truncate max-w-md">
                                    {video.videoUrl}
                                  </p>
                                )}
                              </div>
                              
                              {/* Action Buttons */}
                              <div className="flex items-center gap-1 ml-4">
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                  <Play className="h-4 w-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => video.videoUrl && window.open(video.videoUrl, '_blank')}
                                >
                                  <Link className="h-4 w-4" />
                                </Button>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end" className="masculine-card border-primary/20">
                                    <DropdownMenuItem onClick={() => {
                                      setSelectedVideo(video);
                                      setShowSimilarVideos(true);
                                    }}>
                                      <Wand2 className="mr-2 h-4 w-4 text-orange-500" />
                                      Find Similar Videos
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onClick={() => toggleFavoriteMutation.mutate({ videoId: video.id, isFavorite: video.isFavorite || false })}>
                                      <Heart className={`mr-2 h-4 w-4 ${video.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                                      {video.isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => toggleBookmarkMutation.mutate({ videoId: video.id, isBookmarked: video.isBookmarked || false })}>
                                      <Bookmark className={`mr-2 h-4 w-4 ${video.isBookmarked ? 'fill-blue-500 text-blue-500' : ''}`} />
                                      {video.isBookmarked ? 'Remove Bookmark' : 'Add Bookmark'}
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {videos.map((video) => (
                    <Card key={video.id} className="masculine-card border-primary/20 hover:border-primary/40 transition-colors cursor-pointer group">
                      <div 
                        className="aspect-video bg-gradient-to-br from-primary/20 to-primary/10 relative overflow-hidden cursor-pointer group"
                        onClick={() => {
                          // Navigate to Playing Now page with this video
                          window.location.href = `/?video=${video.id}`;
                        }}
                      >
                        <img
                          src={`data:image/svg+xml;base64,${btoa(`
                            <svg width="320" height="180" xmlns="http://www.w3.org/2000/svg">
                              <defs>
                                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                                  <stop offset="0%" style="stop-color:#${video.videoUrl?.includes('thisvid') ? 'FF6B35' : video.videoUrl?.includes('pornhub') ? 'FFA500' : video.videoUrl?.includes('xvideos') ? 'FF0000' : '6B46C1'};stop-opacity:0.8" />
                                  <stop offset="100%" style="stop-color:#1a1a1a;stop-opacity:1" />
                                </linearGradient>
                              </defs>
                              <rect width="100%" height="100%" fill="url(#grad)"/>
                              <circle cx="160" cy="90" r="30" fill="rgba(255,255,255,0.9)"/>
                              <polygon points="150,75 150,105 180,90" fill="#1a1a1a"/>
                              <text x="160" y="140" text-anchor="middle" fill="white" font-family="Arial" font-size="16" font-weight="bold">${video.videoUrl?.includes('thisvid') ? 'THISVID' : video.videoUrl?.includes('pornhub') ? 'PORNHUB' : video.videoUrl?.includes('xvideos') ? 'XVIDEOS' : 'VIDEO'}</text>
                              <text x="160" y="160" text-anchor="middle" fill="rgba(255,255,255,0.7)" font-family="Arial" font-size="12">Click to Play</text>
                            </svg>
                          `)}`}
                          alt="Video thumbnail"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                          <Play className="h-10 w-10 text-white" />
                        </div>
                      </div>
                      <CardContent className="p-3">
                        <h4 className="text-sm font-medium truncate text-foreground">
                          {video.title === 'External Video' && video.videoUrl ? 
                            (() => {
                              try {
                                const url = new URL(video.videoUrl);
                                const pathSegments = url.pathname.split('/').filter(Boolean);
                                if (pathSegments.length > 0) {
                                  const lastSegment = pathSegments[pathSegments.length - 1];
                                  return lastSegment.replace(/[-_]/g, ' ').substring(0, 30) + '...';
                                }
                                return url.hostname.replace('www.', '') + ' Video';
                              } catch {
                                return 'External Video';
                              }
                            })() : 
                            (video.title?.substring(0, 30) + (video.title?.length > 30 ? '...' : ''))
                          }
                        </h4>
                        <div className="flex items-center justify-between mt-1">
                          <div className="flex items-center gap-1">
                            {video.isExternal && (
                              <Badge variant="secondary" className="text-xs h-4 px-1">URL</Badge>
                            )}
                            {(video.rating || 0) > 0 && (
                              <div className="flex items-center gap-1">
                                <Star className="h-2 w-2 fill-yellow-500 text-yellow-500" />
                                <span className="text-xs text-muted-foreground">{video.rating}</span>
                              </div>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedVideo(video);
                              setShowSimilarVideos(true);
                            }}
                          >
                            <Wand2 className="h-3 w-3 text-orange-500" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="add-url" className="space-y-4">
          <VideoUrlForm />
        </TabsContent>

        <TabsContent value="bulk-import" className="space-y-4">
          <BulkUrlImport />
        </TabsContent>

        <TabsContent value="favorites" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {videos.filter(video => video.isFavorite).map((video) => (
              <Card key={video.id} className="masculine-card border-primary/20 hover:border-primary/40 transition-colors cursor-pointer group"
                onClick={() => window.location.href = `/?video=${video.id}`}>
                <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/10 relative overflow-hidden">
                  <img
                    src={`data:image/svg+xml;base64,${btoa(`
                      <svg width="320" height="180" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#FF6B35;stop-opacity:0.8" />
                            <stop offset="100%" style="stop-color:#1a1a1a;stop-opacity:1" />
                          </linearGradient>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#grad)"/>
                        <circle cx="160" cy="90" r="30" fill="rgba(255,255,255,0.9)"/>
                        <polygon points="150,75 150,105 180,90" fill="#1a1a1a"/>
                        <text x="160" y="140" text-anchor="middle" fill="white" font-family="Arial" font-size="16" font-weight="bold">FAVORITE</text>
                        <text x="160" y="160" text-anchor="middle" fill="rgba(255,255,255,0.7)" font-family="Arial" font-size="12">Click to Play</text>
                      </svg>
                    `)}`}
                    alt="Video thumbnail"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                    <Play className="h-10 w-10 text-white" />
                  </div>
                </div>
                <CardContent className="p-3">
                  <h4 className="text-sm font-medium truncate text-foreground">
                    {video.title?.substring(0, 30) + ((video.title?.length || 0) > 30 ? '...' : '')}
                  </h4>
                </CardContent>
              </Card>
            ))}
          </div>
          {videos.filter(video => video.isFavorite).length === 0 && (
            <p className="text-muted-foreground text-center py-8">No favorite videos yet. Mark videos as favorites from the main library.</p>
          )}
        </TabsContent>

        <TabsContent value="bookmarks" className="space-y-4">
          <p className="text-muted-foreground">Bookmarked videos will appear here.</p>
        </TabsContent>

        <TabsContent value="recent" className="space-y-4">
          <p className="text-muted-foreground">Recently added videos will appear here.</p>
        </TabsContent>

        <TabsContent value="watched" className="space-y-4">
          <p className="text-muted-foreground">Recently watched videos will appear here.</p>
        </TabsContent>
      </Tabs>

      {/* Similar Videos Dialog */}
      <Dialog open={showSimilarVideos} onOpenChange={setShowSimilarVideos}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-orange-500" />
              AI-Powered Similar Videos
              {selectedVideo && (
                <Badge variant="outline" className="ml-2">
                  {selectedVideo.title.length > 30 
                    ? selectedVideo.title.substring(0, 30) + '...' 
                    : selectedVideo.title
                  }
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              Discover similar videos using advanced AI content analysis and tagging
            </DialogDescription>
          </DialogHeader>
          
          {selectedVideo && (
            <SimilarVideos
              videoId={selectedVideo.id}
              currentVideo={{
                title: selectedVideo.title,
                tags: selectedVideo.tags || undefined,
                categories: selectedVideo.categories || undefined
              }}
              onVideoSelect={(videoId) => {
                const newVideo = videos.find((v) => v.id === videoId);
                if (newVideo) {
                  setSelectedVideo(newVideo);
                }
              }}
              showAutoPlay={false}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}