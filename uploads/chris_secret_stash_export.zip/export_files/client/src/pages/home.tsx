import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Play, 
  Heart, 
  Share2, 
  Download,
  Clock,
  Eye,
  ThumbsUp,
  Search,
  Filter,
  Grid3X3,
  List,
  Upload,
  Zap,
  Link,
  Star,
  Bookmark,
  Trash2,
  Plus,
  Video
} from "lucide-react";
import RecommendationSection from "@/components/RecommendationSection";
import VideoLibrary from "@/components/VideoLibrary";
import { AuthenticatedVideoPlayer } from "@/components/AuthenticatedVideoPlayer";
import { VideoThumbnail } from "@/components/VideoThumbnail";
import { AdaptiveColorPalette } from "@/components/AdaptiveColorPalette";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [selectedVideoUrl, setSelectedVideoUrl] = useState("");
  const [selectedVideoId, setSelectedVideoId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [watchStartTime, setWatchStartTime] = useState<number>(0);
  const { toast } = useToast();

  // Fetch real videos from database
  const { data: videos = [], isLoading: videosLoading, error: videosError } = useQuery<any[]>({
    queryKey: ['/api/videos'],
  });



  const { data: recommendedVideos = [] } = useQuery({
    queryKey: ['/api/recommendations/demo-user/hybrid'],
  });

  // Get first video with URL for main player and auto-select it
  const mainVideo = videos.find(v => v.videoUrl) || videos[0] || {
    id: "demo",
    title: "No videos available - Upload some videos to get started",
    videoUrl: "",
    tags: ["demo"],
    performers: [],
    categories: []
  };

  // Auto-select first video on load or handle URL parameter
  useEffect(() => {
    // Check for video ID in URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const videoIdParam = urlParams.get('video');
    
    if (videoIdParam && videos.length > 0) {
      const selectedVideo = videos.find(v => v.id === videoIdParam);
      if (selectedVideo && selectedVideo.videoUrl) {
        setSelectedVideoUrl(selectedVideo.videoUrl);
        setSelectedVideoId(selectedVideo.id);
        setWatchStartTime(Date.now());
        return;
      }
    }
    
    // Default: auto-select first video
    if (videos.length > 0 && !selectedVideoUrl && mainVideo.videoUrl) {
      setSelectedVideoUrl(mainVideo.videoUrl);
      setSelectedVideoId(mainVideo.id);
      setWatchStartTime(Date.now());
    }
  }, [videos, selectedVideoUrl, mainVideo.videoUrl, mainVideo.id]);

  // AI Interaction Tracking
  const recordInteractionMutation = useMutation({
    mutationFn: async (data: any) => apiRequest("/api/recommendations/interaction", {
      method: "POST",
      body: JSON.stringify(data)
    }),
  });

  const saveVideoMutation = useMutation({
    mutationFn: async (videoId: string) => apiRequest(`/api/videos/${videoId}/save`, {
      method: "POST"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Video saved to your collection" });
    }
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (videoId: string) => apiRequest(`/api/videos/${videoId}`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Video removed from library" });
    }
  });

  const rateVideoMutation = useMutation({
    mutationFn: async ({ videoId, rating }: { videoId: string, rating: number }) => 
      apiRequest(`/api/videos/${videoId}/rate`, {
        method: "POST",
        body: JSON.stringify({ rating })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({ title: "Rating saved" });
    }
  });

  const handleVideoSelect = (video: any) => {
    if (video.videoUrl) {
      // Record previous video interaction if there was one
      if (selectedVideoId && watchStartTime > 0) {
        const watchDuration = Date.now() - watchStartTime;
        recordInteractionMutation.mutate({
          userId: "demo-user",
          videoId: selectedVideoId,
          watchDuration: Math.floor(watchDuration / 1000),
          completionPercentage: 0.5, // Default assumption
        });
      }

      setSelectedVideoUrl(video.videoUrl);
      setSelectedVideoId(video.id);
      setWatchStartTime(Date.now());
    }
  };

  const handleRating = (rating: number) => {
    if (selectedVideoId) {
      rateVideoMutation.mutate({ videoId: selectedVideoId, rating });
      
      // Record interaction with rating
      recordInteractionMutation.mutate({
        userId: "demo-user",
        videoId: selectedVideoId,
        watchDuration: Math.floor((Date.now() - watchStartTime) / 1000),
        completionPercentage: 0.8,
        rating
      });
    }
  };

  const extractVideoTitle = (url: string) => {
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.replace('www.', '');
      const pathSegments = urlObj.pathname.split('/').filter(Boolean);
      
      if (pathSegments.length > 0) {
        const lastSegment = pathSegments[pathSegments.length - 1];
        return lastSegment.replace(/[-_]/g, ' ').replace(/\.[^/.]+$/, '').substring(0, 50);
      }
      
      return hostname.charAt(0).toUpperCase() + hostname.slice(1) + ' Video';
    } catch {
      return 'External Video';
    }
  };

  const formatViewCount = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <div className="space-y-6">
      {/* Header with Search */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold masculine-text-gradient">
            Playing Now
          </h1>
          <p className="text-muted-foreground text-sm">
            Watch your videos with intelligent playback and discovery
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search videos, performers, tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-80 border-primary/20 focus:border-primary"
            />
          </div>
          <Button size="sm" variant="outline" className="border-primary/30">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 gap-6">
        {/* Video Player Section - Full width */}
        <div className="xl:col-span-5 space-y-4">
          {/* Main Video Player */}
          <AuthenticatedVideoPlayer 
            videoUrl={selectedVideoUrl || mainVideo.videoUrl}
            onVideoLoad={(video) => {
              // Video loaded successfully - no notification needed
            }}
          />

          {/* Video Info Card (replacing color palette) */}

          {/* Video Info */}
          <Card className="masculine-card border-primary/20">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h2 className="text-lg font-semibold text-foreground">
                      {extractVideoTitle(selectedVideoUrl || mainVideo.videoUrl || '')}
                    </h2>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                      <span className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {formatViewCount(mainVideo.viewCount || 0)} views
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {new Date(mainVideo.createdAt || Date.now()).toLocaleDateString()}
                      </span>
                      {mainVideo.isExternal && (
                        <Badge variant="secondary" className="text-xs">
                          <Link className="h-3 w-3 mr-1" />
                          External
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Rating Stars */}
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Button
                          key={star}
                          size="sm"
                          variant="ghost"
                          className="p-1 h-8 w-8"
                          onClick={() => handleRating(star)}
                        >
                          <Star 
                            className={`h-4 w-4 ${
                              (mainVideo.rating || 0) >= star 
                                ? 'fill-yellow-500 text-yellow-500' 
                                : 'text-muted-foreground'
                            }`} 
                          />
                        </Button>
                      ))}
                    </div>
                    
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-primary/30"
                      onClick={() => selectedVideoId && saveVideoMutation.mutate(selectedVideoId)}
                    >
                      <Bookmark className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-destructive/30 text-destructive hover:bg-destructive/10"
                      onClick={() => selectedVideoId && deleteVideoMutation.mutate(selectedVideoId)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  </div>
                </div>

                {/* Tags */}
                {mainVideo.tags && mainVideo.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {mainVideo.tags.slice(0, 6).map((tag: string) => (
                      <Badge 
                        key={tag} 
                        variant="secondary" 
                        className="bg-primary/10 text-primary border-primary/30 hover:bg-primary/20 cursor-pointer"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Performers */}
                {mainVideo.performers && mainVideo.performers.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-foreground">Performers:</h4>
                    <div className="flex flex-wrap gap-2">
                      {mainVideo.performers.map((performer: string) => (
                        <Badge 
                          key={performer} 
                          variant="outline" 
                          className="border-primary/30 text-primary hover:bg-primary/10 cursor-pointer"
                        >
                          {performer}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>


      </div>

      {/* Video Library Grid */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Your Video Collection</h2>
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <Video className="h-4 w-4" />
            <span>{videos.length} videos available</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {videos.slice(0, 12).map((video: any) => (
            <div
              key={video.id}
              onClick={() => {
                setSelectedVideoUrl(video.videoUrl);
                setSelectedVideoId(video.id);
                setWatchStartTime(Date.now());
              }}
              className={`group cursor-pointer transition-all duration-200 ${
                selectedVideoId === video.id 
                  ? 'ring-2 ring-orange-500 ring-offset-2 ring-offset-zinc-900' 
                  : 'hover:scale-105'
              }`}
            >
              <Card className="masculine-card overflow-hidden">
                <div className="aspect-video bg-zinc-800 relative overflow-hidden">
                  <VideoThumbnail 
                    videoId={video.id}
                    videoUrl={video.videoUrl}
                    title={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10" />
                  <div className="absolute bottom-2 left-2 z-20">
                    <Play className="h-4 w-4 text-white" />
                  </div>
                  <div className="absolute top-2 right-2 z-20">
                    {video.isExternal && (
                      <Badge variant="secondary" className="text-xs bg-orange-500/20 text-orange-300">
                        External
                      </Badge>
                    )}
                  </div>
                </div>
                <CardContent className="p-3">
                  <h3 className="font-medium text-sm line-clamp-2 mb-1">
                    {video.title}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-zinc-400">
                    <Clock className="h-3 w-3" />
                    <span>Added recently</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* AI Recommendations Section */}
      <RecommendationSection 
        videos={videos} 
        onVideoSelect={handleVideoSelect} 
        selectedVideoUrl={selectedVideoUrl} 
      />
    </div>
  );
}