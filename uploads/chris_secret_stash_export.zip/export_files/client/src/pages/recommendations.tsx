import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Play, 
  Heart, 
  Eye, 
  Clock, 
  Star,
  Zap,
  TrendingUp,
  Users,
  Target,
  Shuffle,
  Settings,
  Filter
} from "lucide-react";
import UserPreferences from "@/components/UserPreferences";

// Demo data for the recommendation system
const demoRecommendations = {
  hybrid: [
    {
      id: "1",
      title: "Advanced AI Analytics in Adult Content",
      thumbnailPath: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400&h=225&fit=crop",
      duration: 1800,
      viewCount: 2400,
      rating: 4,
      tags: ["ai", "analytics", "advanced"],
      performers: ["Tech Expert", "AI Specialist"],
      isFavorite: true,
      score: 0.95,
      reason: "Perfect match for your AI interests and viewing history",
      algorithm: "hybrid"
    },
    {
      id: "2", 
      title: "Professional Video Analysis Techniques",
      thumbnailPath: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=225&fit=crop",
      duration: 1200,
      viewCount: 1800,
      rating: 5,
      tags: ["professional", "analysis", "techniques"],
      performers: ["Pro Analyst", "Expert Developer"],
      isFavorite: false,
      score: 0.88,
      reason: "Users with similar preferences highly rated this",
      algorithm: "hybrid"
    },
    {
      id: "3",
      title: "Machine Learning in Media Processing",
      thumbnailPath: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=400&h=225&fit=crop",
      duration: 2100,
      viewCount: 3200,
      rating: 4,
      tags: ["machine-learning", "media", "processing"],
      performers: ["ML Engineer", "Data Scientist"],
      isFavorite: false,
      score: 0.82,
      reason: "Trending among users with similar technical interests",
      algorithm: "hybrid"
    }
  ],
  collaborative: [
    {
      id: "4",
      title: "Community-Recommended Video Analysis",
      thumbnailPath: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=225&fit=crop",
      duration: 900,
      viewCount: 1500,
      rating: 4,
      tags: ["community", "analysis"],
      performers: ["Community Expert"],
      isFavorite: false,
      score: 0.79,
      reason: "Users who watched your favorites also enjoyed this",
      algorithm: "collaborative"
    }
  ],
  content: [
    {
      id: "5",
      title: "Content-Based Filtering Demo",
      thumbnailPath: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=225&fit=crop",
      duration: 1500,
      viewCount: 2100,
      rating: 5,
      tags: ["filtering", "content", "demo"],
      performers: ["Content Expert"],
      isFavorite: true,
      score: 0.91,
      reason: "Matches your preferred tags and performers",
      algorithm: "content"
    }
  ],
  trending: [
    {
      id: "6",
      title: "Hot New Video Processing Tech",
      thumbnailPath: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=225&fit=crop",
      duration: 1800,
      viewCount: 4500,
      rating: 4,
      tags: ["trending", "new", "technology"],
      performers: ["Trending Creator"],
      isFavorite: false,
      score: 0.85,
      reason: "Trending now with 450 views in the last 24 hours",
      algorithm: "trending"
    }
  ]
};

export default function Recommendations() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<'hybrid' | 'collaborative' | 'content' | 'trending'>('hybrid');
  const [showPreferences, setShowPreferences] = useState(false);

  const getAlgorithmIcon = (algorithm: string) => {
    switch (algorithm) {
      case 'collaborative': return <Users className="w-4 h-4" />;
      case 'content': return <Target className="w-4 h-4" />;
      case 'trending': return <TrendingUp className="w-4 h-4" />;
      case 'hybrid': return <Zap className="w-4 h-4" />;
      default: return <Shuffle className="w-4 h-4" />;
    }
  };

  const getAlgorithmColor = (algorithm: string) => {
    switch (algorithm) {
      case 'collaborative': return 'bg-blue-500/20 text-blue-400';
      case 'content': return 'bg-green-500/20 text-green-400';
      case 'trending': return 'bg-red-500/20 text-red-400';
      case 'hybrid': return 'bg-primary/20 text-primary';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${Math.floor(minutes / 60)}:${(minutes % 60).toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const currentRecommendations = demoRecommendations[selectedAlgorithm] || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold masculine-text-gradient">AI Recommendations</h1>
          <p className="text-muted-foreground mt-2">
            Personalized video suggestions powered by advanced machine learning algorithms
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowPreferences(!showPreferences)}
            className="hover-glow border-primary/30"
          >
            <Settings className="w-4 h-4 mr-2" />
            Preferences
          </Button>
          <Button className="masculine-gradient hover:scale-105 transition-transform duration-300 glow-primary">
            <Filter className="w-4 h-4 mr-2" />
            Advanced Filters
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Main Recommendations Section */}
        <div className="xl:col-span-3">
          <Card className="masculine-card border-primary/10">
            <CardHeader>
              <CardTitle className="text-xl masculine-text-gradient flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary glow-secondary" />
                Personalized Video Recommendations
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              {/* Algorithm Selection */}
              <Tabs value={selectedAlgorithm} onValueChange={(value) => setSelectedAlgorithm(value as any)} className="mb-6">
                <TabsList className="grid w-full grid-cols-4 bg-black/40">
                  <TabsTrigger value="hybrid" className="data-[state=active]:masculine-gradient">
                    <Zap className="w-4 h-4 mr-2" />
                    Smart AI
                  </TabsTrigger>
                  <TabsTrigger value="collaborative" className="data-[state=active]:masculine-gradient">
                    <Users className="w-4 h-4 mr-2" />
                    Similar Users
                  </TabsTrigger>
                  <TabsTrigger value="content" className="data-[state=active]:masculine-gradient">
                    <Target className="w-4 h-4 mr-2" />
                    Content Match
                  </TabsTrigger>
                  <TabsTrigger value="trending" className="data-[state=active]:masculine-gradient">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Trending Now
                  </TabsTrigger>
                </TabsList>

                <TabsContent value={selectedAlgorithm} className="mt-6">
                  {/* Algorithm Description */}
                  <div className="mb-6 p-4 bg-black/20 rounded-lg border border-primary/10">
                    <div className="flex items-center gap-2 mb-2">
                      {getAlgorithmIcon(selectedAlgorithm)}
                      <h3 className="font-semibold capitalize">{selectedAlgorithm} Algorithm</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {selectedAlgorithm === 'hybrid' && "Advanced AI combining multiple recommendation techniques for optimal personalization"}
                      {selectedAlgorithm === 'collaborative' && "Recommendations based on users with similar viewing patterns and preferences"}
                      {selectedAlgorithm === 'content' && "Content-based filtering using video attributes, tags, and performers you enjoy"}
                      {selectedAlgorithm === 'trending' && "Popular and trending content based on recent community engagement"}
                    </p>
                  </div>

                  {/* Recommendations Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {currentRecommendations.map((video) => (
                      <Card
                        key={video.id}
                        className="group cursor-pointer hover-glow border-primary/10 transition-all duration-300 hover:scale-105"
                      >
                        <div className="relative">
                          <img
                            src={video.thumbnailPath}
                            alt={video.title}
                            className="w-full h-40 object-cover rounded-t-lg thumbnail-hover"
                          />
                          
                          {/* Play overlay */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-t-lg flex items-center justify-center">
                            <Play className="w-12 h-12 text-white drop-shadow-lg" />
                          </div>

                          {/* Duration badge */}
                          <div className="absolute bottom-2 right-2 masculine-gradient text-white text-xs px-2 py-1 rounded-md font-medium">
                            {formatDuration(video.duration)}
                          </div>

                          {/* Favorite indicator */}
                          {video.isFavorite && (
                            <div className="absolute top-2 left-2">
                              <Heart className="w-5 h-5 fill-primary text-primary glow-primary" />
                            </div>
                          )}

                          {/* Algorithm badge */}
                          <div className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs flex items-center gap-1 ${getAlgorithmColor(video.algorithm)}`}>
                            {getAlgorithmIcon(video.algorithm)}
                            <span className="capitalize font-medium">{video.algorithm}</span>
                          </div>
                        </div>

                        <CardContent className="p-4">
                          <h3 className="font-semibold text-lg leading-tight mb-3 group-hover:text-primary transition-colors line-clamp-2">
                            {video.title}
                          </h3>

                          {/* Recommendation reason */}
                          <div className="mb-4 p-3 bg-primary/5 rounded-lg border border-primary/10">
                            <p className="text-sm text-primary font-medium">
                              {video.reason}
                            </p>
                          </div>

                          {/* Video stats */}
                          <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1">
                                <Eye className="w-4 h-4" />
                                <span>{video.viewCount.toLocaleString()}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 fill-primary text-primary" />
                                <span>{video.rating}/5</span>
                              </div>
                            </div>
                            
                            {/* Confidence score */}
                            <div className="flex items-center gap-1 text-primary font-semibold">
                              <Zap className="w-4 h-4" />
                              <span>{Math.round(video.score * 100)}%</span>
                            </div>
                          </div>

                          {/* Performers */}
                          <div className="mb-3">
                            <p className="text-xs text-muted-foreground mb-1">Performers</p>
                            <div className="flex flex-wrap gap-1">
                              {video.performers.map((performer) => (
                                <Badge key={performer} variant="outline" className="text-xs border-primary/30">
                                  {performer}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          {/* Tags */}
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Tags</p>
                            <div className="flex flex-wrap gap-1">
                              {video.tags.map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Preferences Sidebar */}
        <div className="xl:col-span-1">
          {showPreferences && (
            <UserPreferences userId="demo-user" className="mb-6" />
          )}
          
          {/* Algorithm Stats */}
          <Card className="masculine-card border-primary/10">
            <CardHeader>
              <CardTitle className="text-lg masculine-text-gradient">Recommendation Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Smart AI</span>
                  <Badge className="masculine-gradient">95% Accuracy</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Similar Users</span>
                  <Badge variant="secondary">850 Users</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Content Match</span>
                  <Badge variant="outline">120 Videos</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Trending</span>
                  <Badge className="bg-red-500/20 text-red-400">Hot 🔥</Badge>
                </div>
              </div>
              
              <Separator />
              
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-2">
                  Recommendations improve as you watch more content
                </p>
                <Button size="sm" className="masculine-gradient w-full">
                  <Zap className="w-4 h-4 mr-2" />
                  Refresh Recommendations
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}