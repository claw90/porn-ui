import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import RecommendationSection from "@/components/RecommendationSection";
import { SITE_TEXT } from "@/config/siteText";
import { 
  Play, 
  Users, 
  FolderOpen, 
  Search, 
  BarChart3, 
  Film, 
  Upload, 
  TrendingUp,
  Star,
  Clock,
  Database,
  Cpu,
  ArrowRight
} from "lucide-react";

export default function Dashboard() {
  // Fetch dashboard data
  const { data: recentAnalyses = [] } = useQuery({
    queryKey: ['/api/analyses/recent/5'],
  });

  const { data: videos = [] } = useQuery({
    queryKey: ['/api/videos'],
    queryFn: () => fetch('/api/videos?limit=10').then(res => res.json())
  });

  const { data: performers = [] } = useQuery({
    queryKey: ['/api/performers'],
    queryFn: () => fetch('/api/performers?limit=10').then(res => res.json())
  });

  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
  });

  return (
    <div className="space-y-2 h-screen overflow-hidden">
      {/* Compact Header */}
      <div className="text-center space-y-1">
        <h1 className="text-2xl font-bold collection-text-gradient">
          {SITE_TEXT.siteName}
        </h1>
        <p className="text-xs text-muted-foreground">
          {SITE_TEXT.siteTagline}
        </p>
      </div>

      {/* Quick Actions - Compact */}
      <div className="grid grid-cols-3 gap-2">
        <Link href="/library">
          <Button className="w-full h-12 collection-gradient text-xs">
            <Upload className="h-3 w-3 mr-1" />
            Add Content
          </Button>
        </Link>
        <Link href="/performers">
          <Button className="w-full h-12 border-primary/30 text-xs" variant="outline">
            <Users className="h-3 w-3 mr-1" />
            {SITE_TEXT.navigation.performers}
          </Button>
        </Link>
        <Link href="/discovery">
          <Button className="w-full h-12 border-primary/30 text-xs" variant="outline">
            <Search className="h-3 w-3 mr-1" />
            {SITE_TEXT.navigation.discovery}
          </Button>
        </Link>
      </div>

      {/* Personalized Recommendations - Direct Integration */}
      <div className="flex-1">
        <RecommendationSection />
      </div>
    </div>
  );
}