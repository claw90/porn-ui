import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Upload, 
  FileVideo, 
  User, 
  Play, 
  Clock, 
  Target,
  Brain,
  Eye,
  AlertTriangle,
  CheckCircle,
  ArrowLeft,
  Search
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import InternetPerformerSearch from "@/components/InternetPerformerSearch";

interface Analysis {
  id: string;
  videoFile: string;
  faceFile: string;
  tolerance: number;
  frameSkip: number;
  generateThumbnails: boolean;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  results?: {
    totalFrames: number;
    matchCount: number;
    matches: Array<{
      frameNumber: number;
      timestamp: number;
      confidence: number;
      thumbnailPath?: string;
    }>;
  };
  error?: string;
  createdAt: string;
}

export default function FaceRecognition() {
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [selectedFace, setSelectedFace] = useState<File | null>(null);
  const [tolerance, setTolerance] = useState(0.5);
  const [frameSkip, setFrameSkip] = useState(5);
  const [generateThumbnails, setGenerateThumbnails] = useState(true);
  const [activeTab, setActiveTab] = useState<'analysis' | 'search'>('analysis');
  const { toast } = useToast();

  // Fetch recent analyses
  const { data: analyses = [], isLoading: analysesLoading } = useQuery<Analysis[]>({
    queryKey: ['/api/analyses/recent/10'],
  });

  // Create new analysis mutation
  const createAnalysisMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/analyses', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        throw new Error('Failed to create analysis');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Analysis Started",
        description: "Face recognition analysis has begun. Check back for results.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/analyses/recent/10'] });
      setSelectedVideo(null);
      setSelectedFace(null);
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to start analysis",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedVideo && !selectedFace) {
      toast({
        title: "Missing Files",
        description: "Please select either a video file or a face image to analyze.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    
    if (selectedVideo) {
      formData.append('video', selectedVideo);
    }
    
    if (selectedFace) {
      formData.append('face', selectedFace);
    }
    
    formData.append('tolerance', tolerance.toString());
    formData.append('frameSkip', frameSkip.toString());
    formData.append('generateThumbnails', generateThumbnails.toString());

    createAnalysisMutation.mutate(formData);
  };

  const formatTimestamp = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent">
            Face Recognition Analysis
          </h1>
          <p className="text-zinc-400 mt-1">
            Upload videos and face images to find matches across your content
          </p>
        </div>
      </div>

      <Alert className="border-orange-500/50 bg-orange-500/10">
        <Brain className="h-4 w-4 text-orange-500" />
        <AlertDescription className="text-orange-100">
          <strong>Backend Feature:</strong> This face recognition system runs server-side analysis 
          using Python scripts. You can start analysis with either a video file OR a target face image - both are not required.
        </AlertDescription>
      </Alert>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-zinc-800/50 p-1 rounded-lg mb-6">
        <button
          onClick={() => setActiveTab('analysis')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'analysis'
              ? 'bg-orange-600 text-white'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-700'
          }`}
        >
          <Target className="h-4 w-4" />
          Face Analysis
        </button>
        <button
          onClick={() => setActiveTab('search')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'search'
              ? 'bg-orange-600 text-white'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-700'
          }`}
        >
          <Search className="h-4 w-4" />
          Internet Search
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'analysis' ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="masculine-card border-blue-500/20">
              <CardContent className="p-4 text-center">
                <FileVideo className="h-8 w-8 mx-auto mb-2 text-blue-400" />
                <h3 className="font-medium text-blue-200">Video Only</h3>
                <p className="text-xs text-blue-300/80">Detect all faces in video</p>
              </CardContent>
            </Card>
            <Card className="masculine-card border-purple-500/20">
              <CardContent className="p-4 text-center">
                <User className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                <h3 className="font-medium text-purple-200">Face Only</h3>
                <p className="text-xs text-purple-300/80">Analyze face characteristics</p>
              </CardContent>
            </Card>
            <Card className="masculine-card border-green-500/20">
              <CardContent className="p-4 text-center">
                <Search className="h-8 w-8 mx-auto mb-2 text-green-400" />
                <h3 className="font-medium text-green-200">Both Files</h3>
                <p className="text-xs text-green-300/80">Find specific face in video</p>
              </CardContent>
            </Card>
          </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Form */}
        <Card className="masculine-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Start New Analysis
            </CardTitle>
            <CardDescription>
              Upload either a video file or target face image (or both) for analysis
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Video Upload */}
              <div className="space-y-2">
                <Label htmlFor="video">Video File (Optional)</Label>
                <div className="border-2 border-dashed border-zinc-700 rounded-lg p-4 text-center">
                  <input
                    id="video"
                    type="file"
                    accept="video/*"
                    onChange={(e) => setSelectedVideo(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                  <label htmlFor="video" className="cursor-pointer">
                    <FileVideo className="h-8 w-8 mx-auto mb-2 text-zinc-400" />
                    {selectedVideo ? (
                      <p className="text-green-400">{selectedVideo.name}</p>
                    ) : (
                      <p className="text-zinc-400">Click to select video file</p>
                    )}
                  </label>
                </div>
              </div>

              {/* Face Upload */}
              <div className="space-y-2">
                <Label htmlFor="face">Target Face Image (Optional)</Label>
                <div className="border-2 border-dashed border-zinc-700 rounded-lg p-4 text-center">
                  <input
                    id="face"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setSelectedFace(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                  <label htmlFor="face" className="cursor-pointer">
                    <User className="h-8 w-8 mx-auto mb-2 text-zinc-400" />
                    {selectedFace ? (
                      <p className="text-green-400">{selectedFace.name}</p>
                    ) : (
                      <p className="text-zinc-400">Click to select face image</p>
                    )}
                  </label>
                </div>
              </div>

              {/* Analysis Parameters */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tolerance">Detection Tolerance</Label>
                  <Input
                    id="tolerance"
                    type="number"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={tolerance}
                    onChange={(e) => setTolerance(parseFloat(e.target.value))}
                  />
                  <p className="text-xs text-zinc-500">Lower = stricter matching</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="frameSkip">Frame Skip Rate</Label>
                  <Input
                    id="frameSkip"
                    type="number"
                    min="1"
                    max="30"
                    value={frameSkip}
                    onChange={(e) => setFrameSkip(parseInt(e.target.value))}
                  />
                  <p className="text-xs text-zinc-500">Analyze every N frames</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  id="thumbnails"
                  type="checkbox"
                  checked={generateThumbnails}
                  onChange={(e) => setGenerateThumbnails(e.target.checked)}
                  className="rounded"
                />
                <Label htmlFor="thumbnails">Generate match thumbnails</Label>
              </div>

              <Button 
                type="submit" 
                disabled={(!selectedVideo && !selectedFace) || createAnalysisMutation.isPending}
                className="w-full bg-gradient-to-r from-orange-600 to-pink-600 hover:from-orange-700 hover:to-pink-700"
              >
                {createAnalysisMutation.isPending ? (
                  <>Processing...</>
                ) : (
                  <>
                    <Target className="h-4 w-4 mr-2" />
                    {selectedVideo && selectedFace ? 'Match Face in Video' : 
                     selectedVideo ? 'Analyze Video' : 
                     selectedFace ? 'Analyze Face' : 'Select Files to Start'}
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent Analyses */}
        <Card className="masculine-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Recent Analyses
            </CardTitle>
            <CardDescription>
              Track the status of your face recognition jobs
            </CardDescription>
          </CardHeader>
          <CardContent>
            {analysesLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-zinc-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-zinc-800 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : analyses.length === 0 ? (
              <p className="text-zinc-400 text-center py-8">
                No analyses yet. Start your first face recognition job above.
              </p>
            ) : (
              <div className="space-y-4">
                {analyses.map((analysis) => (
                  <div key={analysis.id} className="border border-zinc-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">
                        {analysis.videoFile.split('/').pop()}
                      </div>
                      <Badge 
                        variant={
                          analysis.status === 'completed' ? 'default' :
                          analysis.status === 'failed' ? 'destructive' :
                          analysis.status === 'processing' ? 'secondary' : 'outline'
                        }
                      >
                        {analysis.status === 'completed' && <CheckCircle className="h-3 w-3 mr-1" />}
                        {analysis.status === 'failed' && <AlertTriangle className="h-3 w-3 mr-1" />}
                        {analysis.status === 'processing' && <Play className="h-3 w-3 mr-1" />}
                        {analysis.status}
                      </Badge>
                    </div>

                    {analysis.status === 'processing' && (
                      <Progress value={analysis.progress} className="mb-2" />
                    )}

                    {analysis.results && (
                      <div className="text-sm text-zinc-400 space-y-1">
                        <div>Found {analysis.results.matchCount} matches in {analysis.results.totalFrames} frames</div>
                        {analysis.results.matches.slice(0, 3).map((match, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <Clock className="h-3 w-3" />
                            <span>{formatTimestamp(match.timestamp)}</span>
                            <span className="text-green-400">
                              {Math.round(match.confidence * 100)}% confident
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {analysis.error && (
                      <div className="text-sm text-red-400 mt-2">
                        Error: {analysis.error}
                      </div>
                    )}

                    <div className="text-xs text-zinc-500 mt-2">
                      Started: {new Date(analysis.createdAt).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      </>
    ) : (
      <InternetPerformerSearch />
    )}
    </div>
  );
}