# Chris' Secret Stash - Project Export

## Overview
This is a comprehensive adult content management system with AI-powered features including video discovery, recommendations, face recognition, duplicate detection, and advanced filtering capabilities.

## Project Structure

### Core Application Files
- `client/index.html` - Main HTML template
- `client/src/index.css` - Main stylesheet with Tailwind CSS and custom themes
- `client/src/main.tsx` - Application entry point
- `client/src/App.tsx` - Main app component with routing

### Frontend Components
- `client/src/components/` - Reusable UI components
  - `CollapsibleSidebar.tsx` - Navigation sidebar
  - `InternetVideoSearch.tsx` - Video discovery system
  - `VideoPlayer.tsx` - Video playback components
  - `BulkUrlImport.tsx` - Bulk video import functionality
  - Various UI components (buttons, cards, forms, etc.)

### Pages
- `client/src/pages/` - Main application pages
  - `home.tsx` - "Playing Now" video player page
  - `library.tsx` - Video collection management
  - `discovery.tsx` - AI-powered video discovery
  - `recommendations.tsx` - Personalized recommendations
  - `performers.tsx` - Performer/actor management
  - `settings.tsx` - Application settings

### Backend
- `server/index.ts` - Express server entry point
- `server/routes.ts` - API endpoints
- `server/storage.ts` - Database operations
- `shared/schema.ts` - Database schema and types

### Configuration
- `package.json` - Dependencies and scripts
- `tailwind.config.ts` - Tailwind CSS configuration
- `vite.config.ts` - Vite build configuration
- `tsconfig.json` - TypeScript configuration

## Technology Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui components
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **State Management**: TanStack Query
- **Routing**: Wouter

## Key Features
1. **Video Library Management** - Upload, organize, and manage adult video content
2. **AI-Powered Discovery** - Automatic video discovery from multiple platforms
3. **Smart Recommendations** - Personalized video recommendations using AI
4. **Face Recognition** - Advanced face detection and matching capabilities
5. **Bulk Import** - Import hundreds of video URLs at once
6. **Advanced Filtering** - Search by tags, categories, duration, ratings
7. **Duplicate Detection** - Prevent duplicate content in library
8. **Professional UI** - Dark masculine theme with responsive design

## Installation & Setup
1. Install dependencies: `npm install`
2. Set up PostgreSQL database
3. Configure environment variables (DATABASE_URL)
4. Run development server: `npm run dev`

## Notes
- This is a full-stack application requiring both frontend and backend
- Database schema is defined in `shared/schema.ts`
- Uses TypeScript throughout for type safety
- Built with modern React patterns and best practices
- Optimized for desktop usage with professional dark theme

For questions or support, refer to the original project documentation in `replit.md`.