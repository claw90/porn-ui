from flask import Flask, render_template, request, jsonify
import json, os

app = Flask(__name__)
VIDEO_FOLDER = 'videos'
THUMB_FOLDER = 'static/thumbs'
DATA_FILE = 'vault.json'

def load_data():
    return json.load(open(DATA_FILE)) if os.path.exists(DATA_FILE) else {'videos': []}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/videos')
def videos():
    data = load_data()
    return jsonify(data)

@app.route('/api/download', methods=['POST'])
def download():
    urls = request.json.get('urls', [])
    # Trigger download logic here
    return jsonify({'status': 'queued', 'count': len(urls)})

@app.route('/api/thumbnail', methods=['POST'])
def thumbnail():
    # Trigger thumbnail generation
    return jsonify({'status': 'ok'})

@app.route('/api/keywords')
def keywords():
    # Return extracted keywords
    return jsonify({'keywords': []})

if __name__ == '__main__':
    app.run(debug=True)
