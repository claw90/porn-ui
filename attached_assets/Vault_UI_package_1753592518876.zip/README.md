# Vault UI Project Overview

**Date:** July 27, 2025

## 1. Project Scope
- **Unified Secret Stash UI**: All files and features in the Secret Stash UI folder work together to create a robust video vault interface.
- **Purpose**: Manage, organize, and interact with video URLs from any source in a user-friendly browser interface.

## 2. Key Features
- **Card-Style Layout**: Dark or neutral background, video cards showing thumbnail, title, emoji rating, and save-for-later button.
- **Two-Column View**: 
  - **Upcoming Videos**: URLs yet to be watched.
  - **History**: Recently watched videos with required rating before moving on.
- **Tools Section**: Always visible at the top for:
  - Manual download trigger
  - Thumbnail generation
  - Paste-multiple-URLs box
- **Automated Downloads**: 
  - Runs on a 5-minute idle timer.
  - Logs count of videos downloaded each run.
  - Supports any video URL, not limited to a single site.
- **Metadata & Keywords**:
  - Extract keywords from URLs (e.g., “reading-in-the-bath-tub”).
  - Click keyword to filter and view related videos.
- **Favorites & Watch History**:
  - Mark favorites.
  - If a video has been watched, move to “History” and give a hint before replay.
- **Error Handling**: Log failed loads for review.

## 3. Code Files
- **index.html**: Main UI template with two columns, tool bar, video card markup.
- **server.py**: Flask backend serving video data, handling download and thumbnail requests.
- **content-script.js**: (if used) Initialization and inline script for UI behavior.
- **utils/thumbgen.py**: Updated thumbnail generation script.

## 4. Style & UX Preferences
- **Visual Theme**: Dark or muted background with bright card elements for contrast (neon optional).
- **Typography**: Clean, sans-serif fonts for readability.
- **Icons & Emojis**: Use emojis for quick reactions; consistent icon style throughout.
- **Interaction**: Drag-and-drop or bulk paste for adding URLs.

## 5. User Feedback & Reactions
- Appreciates **streamlined**, **one-click** flows over manual steps.
- Wants to **visualize** progress: clear watched vs queued.
- Likes **emoji** ratings and **card layouts** that feel modern.
- Desires minimal setup: auto-downloads and idle triggers reduce friction.

## 6. Next Steps
1. Finalize HTML/CSS for responsive card grid.
2. Complete backend routes for /api/videos, /api/download, /api/thumbnail, /api/keywords.
3. Integrate idle-detection logic in JavaScript.
4. Hook up utils/thumbgen.py to server endpoints.
5. QA: Test with ~100 sample URLs, verify logging and filters.
