from flask import Flask, jsonify, request, send_from_directory, render_template
import os, json
from datetime import datetime

app = Flask(__name__)
VIDEO_DIR = os.path.join("static", "videos")
META_FILE = "metadata.json"

def extract_keywords(filename):
    base = os.path.splitext(filename)[0]
    return [word.lower() for word in base.replace('-', ' ').replace('_', ' ').split() if len(word) > 3]

def scan_videos():
    metadata = {}
    if os.path.exists(META_FILE):
        with open(META_FILE, 'r') as f:
            metadata = json.load(f)

    updated = {}
    for fname in os.listdir(VIDEO_DIR):
        if not fname.endswith(".mp4"):
            continue
        path = os.path.join(VIDEO_DIR, fname)
        stat = os.stat(path)
        date = datetime.fromtimestamp(stat.st_mtime).isoformat()
        title = os.path.splitext(fname)[0].replace('_', ' ').title()
        updated[fname] = {
            "filename": fname,
            "title": title,
            "date": date,
            "keywords": extract_keywords(fname),
            "rating": metadata.get(fname, {}).get("rating", 0),
            "favorite": metadata.get(fname, {}).get("favorite", False)
        }

    with open(META_FILE, 'w') as f:
        json.dump(updated, f, indent=2)

    return updated

@app.route("/")
def index():
    return send_from_directory(".", "index.html")

@app.route("/api/metadata")
def metadata():
    return jsonify(scan_videos().values())

@app.route("/api/rate", methods=["POST"])
def rate():
    data = request.json
    filename = data["filename"]
    metadata = scan_videos()
    if filename in metadata:
        metadata[filename]["rating"] = metadata[filename].get("rating", 0) + 1
        with open(META_FILE, 'w') as f:
            json.dump(metadata, f, indent=2)
    return '', 204

@app.route("/api/favorite", methods=["POST"])
def favorite():
    data = request.json
    filename = data["filename"]
    metadata = scan_videos()
    if filename in metadata:
        metadata[filename]["favorite"] = True
        with open(META_FILE, 'w') as f:
            json.dump(metadata, f, indent=2)
    return '', 204

if __name__ == "__main__":
    os.makedirs(VIDEO_DIR, exist_ok=True)
    app.run(debug=False)
